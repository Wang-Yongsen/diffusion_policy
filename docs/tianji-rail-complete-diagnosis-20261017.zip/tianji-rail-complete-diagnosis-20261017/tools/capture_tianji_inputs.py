#!/usr/bin/env python3
"""Capture one unengaged Tianji observation, close devices, then infer on CPU.

Run from the diffusion_policy project directory, or pass --project-root.
--replay reads an existing raw_observation.npz without constructing any devices.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import importlib
import hashlib
import inspect
import json
from pathlib import Path
import sys
import subprocess
import time

import numpy as np

OBS_KEYS = ("camera_0", "camera_1", "camera_2", "robot_eef_pose", "hand_joint")


def load_api(project_root):
    project_root = Path(project_root).expanduser().resolve()
    if not (project_root / "eval_tianji_rail.py").is_file():
        raise FileNotFoundError("Use --project-root pointing to the diffusion_policy repository")
    sys.path.insert(0, str(project_root))
    return importlib.import_module("eval_tianji_rail")


def json_default(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def write_json(path, value):
    # Every output directory is new; exclusive files also prevent accidental reuse.
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, default=json_default, ensure_ascii=False, indent=2,
                  allow_nan=False)


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_provenance(api, policy, project_root):
    if not getattr(api, "__name__", None):
        return {"note": "injected API (mock test)"}
    names = [
        "diffusion_policy.real_world.tianji_rail_env",
        "diffusion_policy.real_world.tianji_policy_runtime",
        type(policy).__module__,
        "diffusion_policy.third_party.bimanual_teleop.recording.camera",
        "diffusion_policy.third_party.bimanual_teleop.devices.tianji.model",
        "diffusion_policy.third_party.bimanual_teleop.devices.tianji.driver",
        "diffusion_policy.third_party.bimanual_teleop.devices.wuji.adapter",
    ]
    files = {}
    for name in dict.fromkeys(names):
        path = Path(inspect.getfile(importlib.import_module(name))).resolve()
        files[name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    git = {}
    for key, command in (("commit", ["rev-parse", "HEAD"]),
                         ("status_porcelain", ["status", "--porcelain"])):
        try:
            git[key] = subprocess.check_output(["git", "-C", str(project_root), *command],
                                               text=True, stderr=subprocess.STDOUT, timeout=10).strip()
        except (subprocess.SubprocessError, OSError) as error:
            git[key] = {"unavailable": str(error)}
    git["dirty"] = bool(git["status_porcelain"]) if isinstance(git["status_porcelain"], str) else None
    return {"files": files, "git": git}


def capture_observation(api, config, n_obs_steps, timeout_s):
    env = api.TianjiRailEnv(config, n_obs_steps, motion=False)
    try:
        env.start()
        deadline = time.monotonic() + timeout_s
        last_wait = "waiting for observation"
        while time.monotonic() < deadline:
            try:
                obs, anchor_ns, alignment = env.get_obs()
                # Copy arrays and in-memory metadata before closing. No engagement,
                # action execution or runtime submission is requested by this tool.
                obs = {key: np.array(obs[key], copy=True) for key in OBS_KEYS}
                metadata = {
                    "anchor_ns": int(anchor_ns),
                    "captured_monotonic_ns": time.monotonic_ns(),
                    "alignment": deepcopy(alignment),
                    "camera_metadata": deepcopy(env.cameras.metadata),
                    "driver_metadata": deepcopy(env.driver.metadata),
                    "hand_metadata": {side: deepcopy(hand.metadata)
                                      for side, hand in env.hands.items()},
                }
                return obs, metadata
            except api.ObservationNotReady as error:
                last_wait = str(error)
                time.sleep(0.01)
        raise TimeoutError(f"No complete observation within {timeout_s:g}s: {last_wait}")
    finally:
        # This runs before image writing, checkpoint prediction, or any return.
        env.close()


def load_observation(path):
    with np.load(path, allow_pickle=False) as archive:
        obs = {key: np.array(archive[key], copy=True) for key in OBS_KEYS}
        hz = float(archive["__sample_hz"].item())
        anchor_ns = int(archive["__anchor_ns"].item())
    return obs, hz, anchor_ns


def save_observation(output, obs, sample_hz, anchor_ns):
    from PIL import Image

    np.savez_compressed(output / "raw_observation.npz", **obs,
                        __sample_hz=np.float64(sample_hz),
                        __anchor_ns=np.int64(anchor_ns))
    for key in OBS_KEYS[:3]:
        Image.fromarray(obs[key][-1], mode="RGB").save(output / f"{key}_last.png")


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--checkpoint", required=True, type=Path)
    result.add_argument("--config", type=Path, help="Actual deployment YAML; required for capture")
    result.add_argument("--replay", type=Path, metavar="RAW_OBSERVATION_NPZ")
    result.add_argument("--output", required=True, type=Path, help="New directory; existing paths rejected")
    result.add_argument("--project-root", type=Path, default=Path.cwd())
    result.add_argument("--timeout-s", type=float, default=30.0)
    result.add_argument("--cpu-threads", type=int, default=2)
    result.add_argument("--seed", type=int, help="Default: checkpoint training seed")
    return result


def main(argv=None, *, api=None):
    args = parser().parse_args(argv)
    if args.config is None and args.replay is None:
        raise ValueError("Capture requires --config with the actual deployment YAML")
    if not np.isfinite(args.timeout_s) or args.timeout_s <= 0 or args.cpu_threads < 1:
        raise ValueError("timeout-s must be positive and finite; cpu-threads must be positive")
    output = args.output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=False)
    try:
        api = api or load_api(args.project_root)
        import torch

        torch.set_num_threads(args.cpu_threads)
        policy, cfg, model_key = api.load_policy(args.checkpoint.expanduser(), "cpu")
        config = api.load_deployment_config(args.config.expanduser()) if args.config else None
        if config is not None:
            api.validate_policy_frequency(cfg, config["policy_hz"])
        if args.replay is not None:
            obs, sample_hz, anchor_ns = load_observation(args.replay.expanduser())
            api.validate_policy_frequency(cfg, sample_hz)
            metadata = {"mode": "replay", "source_observation": str(args.replay.resolve()),
                        "anchor_ns": anchor_ns}
        else:
            sample_hz = float(config["policy_hz"])
            obs, metadata = capture_observation(api, config, int(cfg.n_obs_steps), args.timeout_s)
            anchor_ns = metadata["anchor_ns"]
            metadata["mode"] = "capture"
        prepared = api.preprocess_observation(obs, cfg.task.shape_meta, cfg.task.dataset)
        if any(value.shape[0] != int(cfg.n_obs_steps) for value in prepared.values()):
            raise ValueError("Observation time dimension differs from checkpoint n_obs_steps")
        save_observation(output, obs, sample_hz, anchor_ns)
        metadata.update({
            "checkpoint": str(args.checkpoint.expanduser().resolve()), "model_key": model_key,
            "checkpoint_sha256": file_sha256(args.checkpoint.expanduser())
                                 if args.checkpoint.expanduser().is_file() else None,
            "sample_hz": sample_hz, "deployment_config_path": str(args.config.resolve()) if args.config else None,
            "deployment_config": config, "checkpoint_config": api.OmegaConf.to_container(cfg, resolve=True),
            "runtime_entrypoint": getattr(api, "__file__", None),
            "source_provenance": source_provenance(api, policy, args.project_root),
            "observation_shapes": {key: list(value.shape) for key, value in obs.items()},
        })
        write_json(output / "metadata.json", metadata)
        seed = int(args.seed if args.seed is not None else cfg.training.seed)
        torch.manual_seed(seed)
        np.random.seed(seed)
        policy.reset()
        tensors = {key: torch.from_numpy(value).unsqueeze(0).to("cpu")
                   for key, value in prepared.items()}
        begin = time.monotonic()
        with torch.inference_mode():
            result = policy.predict_action(tensors)
        prediction = {key: value.detach().cpu().numpy()[0]
                      for key, value in result.items() if key in ("action", "action_pred")}
        action = prediction["action"]
        if (action.shape != (int(cfg.n_action_steps), 52)
                or any(not np.isfinite(value).all() for value in prediction.values())):
            raise ValueError("Invalid checkpoint prediction shape or nonfinite action")
        np.savez_compressed(output / "prediction.npz", **prediction)
        summary = {"seed": seed, "inference_s": time.monotonic() - begin,
                   "current_eef_pose": obs["robot_eef_pose"][-1],
                   "first_action": action[0], "last_action": action[-1],
                   "action_shape": list(action.shape)}
        write_json(output / "summary.json", summary)
        print("Actual EEF [left xyz+rotvec, right xyz+rotvec]:", obs["robot_eef_pose"][-1])
        print("First target EEF:", action[0, :12])
        print("Last target EEF:", action[-1, :12])
        print(f"Saved {output}")
        return output
    except Exception as error:
        write_json(output / "error.json", {"type": type(error).__name__, "message": str(error)})
        raise


if __name__ == "__main__":
    main()
