"""Hardware-free contract checks for the standalone observation snapshot tool."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import Mock

import numpy as np
from omegaconf import OmegaConf
import torch

SPEC = importlib.util.spec_from_file_location("capture_tianji_inputs", Path(__file__).with_name("capture_tianji_inputs.py"))
capture = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(capture)


class ObservationNotReady(RuntimeError):
    pass


def observation():
    result = {f"camera_{i}": np.full((2, 8, 8, 3), i * 40, np.uint8) for i in range(3)}
    result.update(robot_eef_pose=np.zeros((2, 12), np.float32),
                  hand_joint=np.zeros((2, 40), np.float32))
    return result


class SnapshotTests(unittest.TestCase):
    def make_api(self, env):
        cfg = OmegaConf.create({"n_obs_steps": 2, "n_action_steps": 8, "training": {"seed": 42},
                                "task": {"shape_meta": {}, "dataset": {}}})
        policy = Mock()
        policy.predict_action.return_value = {"action": torch.zeros((1, 8, 52)),
                                             "action_pred": torch.zeros((1, 16, 52))}
        return SimpleNamespace(TianjiRailEnv=Mock(return_value=env),
                               ObservationNotReady=ObservationNotReady,
                               load_policy=Mock(return_value=(policy, cfg, "ema_model")),
                               load_deployment_config=Mock(return_value={"policy_hz": 30}),
                               validate_policy_frequency=Mock(), OmegaConf=OmegaConf,
                               preprocess_observation=lambda obs, *args: {
                                   k: np.moveaxis(v, -1, 1).astype(np.float32) / 255
                                   if k.startswith("camera") else v for k, v in obs.items()})

    def make_env(self):
        env = Mock()
        env.cameras.metadata = {"camera_0": {"serial": "mock"}}
        env.driver.metadata = {"model_sha256": "mock"}
        env.hands = {}
        env.get_obs.return_value = (observation(), 100, {"query_ns": [67, 100]})
        return env

    def test_capture_never_engages_or_submits_and_closes_before_prediction(self):
        env = self.make_env()
        env.get_obs.side_effect = [ObservationNotReady("warmup"), env.get_obs.return_value]
        api = self.make_api(env)
        predict = api.load_policy.return_value[0].predict_action
        result = predict.return_value
        predict.side_effect = lambda obs: (env.close.assert_called_once(), result)[1]
        with tempfile.TemporaryDirectory() as root:
            output = Path(root) / "capture"
            capture.main(["--checkpoint", "fake.ckpt", "--config", "actual.yaml", "--output", str(output)], api=api)
            self.assertTrue((output / "raw_observation.npz").is_file())
            self.assertTrue((output / "camera_1_last.png").is_file())
            self.assertTrue((output / "prediction.npz").is_file())
        api.TianjiRailEnv.assert_called_once_with({"policy_hz": 30}, 2, motion=False)
        env.engage.assert_not_called()
        env.exec_actions.assert_not_called()
        env.runtime.submit.assert_not_called()
        env.arm.submit.assert_not_called()

    def test_start_or_observation_exception_still_closes(self):
        for fail_at in ("start", "get_obs"):
            with self.subTest(fail_at=fail_at):
                env = self.make_env()
                getattr(env, fail_at).side_effect = RuntimeError("mock failure")
                api = self.make_api(env)
                with self.assertRaisesRegex(RuntimeError, "mock failure"):
                    capture.capture_observation(api, {}, 2, 1)
                env.close.assert_called_once()
                env.engage.assert_not_called()
                env.exec_actions.assert_not_called()

    def test_replay_constructs_no_hardware_and_refuses_existing_output(self):
        api = self.make_api(self.make_env())
        with tempfile.TemporaryDirectory() as root:
            source = Path(root) / "source.npz"
            np.savez_compressed(source, **observation(), __sample_hz=30., __anchor_ns=100)
            output = Path(root) / "replay"
            args = ["--checkpoint", "fake.ckpt", "--replay", str(source), "--output", str(output)]
            capture.main(args, api=api)
            api.TianjiRailEnv.assert_not_called()
            api.load_deployment_config.assert_not_called()
            api.validate_policy_frequency.assert_called_once()
            with self.assertRaises(FileExistsError):
                capture.main(args, api=api)


if __name__ == "__main__":
    unittest.main()
