"""No devices: ideal joint integration of existing CartesianServo; teacher images are externally replayed."""
import os,time,json
os.environ['CUDA_VISIBLE_DEVICES']=''
from pathlib import Path
import numpy as np,torch,hydra
from scipy.spatial.transform import Rotation
from threadpoolctl import threadpool_limits
from eval_tianji_rail import load_policy
from diffusion_policy.third_party.bimanual_teleop.devices.tianji.model import TianjiKinematics
from diffusion_policy.third_party.bimanual_teleop.control.arm.servo import CartesianServo
from diffusion_policy.third_party.bimanual_teleop.types import Pose
out=Path(__file__).parent;torch.set_num_threads(2);torch.set_num_interop_threads(2);t0=time.time()
kin=TianjiKinematics()
def vector(pose):return np.r_[pose.position_m,Rotation.from_quat(pose.orientation_xyzw).as_rotvec()]
def goal(v,side='left'):return Pose(f'tianji_{side}_base',f'tianji_{side}_flange',tuple(v[:3]),tuple(Rotation.from_rotvec(v[3:6]).as_quat()))
class Integrator:
 def __init__(self,q,side):
  self.side=side
  self.servo=CartesianServo(kin,self.side,kin.model,velocity_ratio=15,acceleration_ratio=15);self.servo.reset(tuple(q));self.t=0.;self.history=[(0.,vector(kin.fk(self.side,tuple(q))))];self.lastgoal=kin.fk(self.side,tuple(q));self.samples=[]
 def advance(self,target,duration):
  remaining=float(duration)
  while remaining>1e-9:
   dt=min(.005,remaining);step=self.servo.propose(target,dt);self.servo.accept(step);self.t+=dt
   self.history.append((self.t,vector(step.pose)));self.samples.append((self.t,step.position_error_m,step.orientation_error_rad,step.limited,step.progress));remaining-=dt
  self.lastgoal=target
 def history_obs(self):
  ts=np.array([x[0] for x in self.history]);vv=np.array([x[1] for x in self.history]);query=[max(0.,self.t-1/30),self.t]
  vals=[]
  for t in query:
   idx=int(np.searchsorted(ts,t,side='left'));idx=min(idx,len(ts)-1)
   if idx==0 or ts[idx]==t:vals.append(vv[idx]);continue
   lower=idx-1;f=(t-ts[lower])/(ts[idx]-ts[lower]);v=vv[lower]+f*(vv[idx]-vv[lower]);
   from scipy.spatial.transform import Slerp
   v[3:6]=Slerp([0.,1.],Rotation.from_rotvec(vv[[lower,idx],3:6]))([f]).as_rotvec()[0];vals.append(v)
  return np.array(vals,dtype=np.float32)
 def execute(self,actions):
  self.advance(self.lastgoal,.16)
  for a in actions:self.advance(goal(a[:6],self.side),1/30)
  return vector(kin.fk(self.side,self.servo.q))
with threadpool_limits(limits=2),torch.inference_mode():
 policy,cfg,key=load_policy('data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt','cpu');ds=hydra.utils.instantiate(cfg.task.dataset);lookup={int(s):i for i,(s,_) in enumerate(ds.indices)}
 q=np.asarray(ds.data['robot_joint'][0],dtype=float);sim={side:Integrator(q[i*7:(i+1)*7],side) for i,side in enumerate(['left','right'])};hand=np.asarray(ds.data['hand_joint'][0],dtype=np.float32);rows=[];cached=[]
 enc=policy.obs_encoder
 def encode(obs):
  nobs=policy.normalizer.normalize(obs);feats={}
  for k in enc.obs_shapes:
   x=nobs[k].reshape(-1,*nobs[k].shape[2:])
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_in(x)
   if enc.obs_nets[k] is not None:
    x=enc.obs_nets[k](x)
    if enc.activation is not None:x=enc.activation(x)
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_out(x)
   feats[k]=x.reshape(1,2,-1)
  return feats
 def predict(feats,seed):
  cond=torch.cat([feats[k] for k in enc.obs_shapes],dim=-1);zeros=torch.zeros((1,16,52));torch.manual_seed(seed);policy.reset()
  sample=policy.conditional_sample(zeros,torch.zeros_like(zeros,dtype=torch.bool),cond=cond,**policy.kwargs)
  return policy.normalizer['action'].unnormalize(sample)[0,1:9].cpu().numpy()
 for block in range(20):
  frame=block*8;sample=ds[lookup[frame]];obs={k:v.unsqueeze(0) for k,v in sample['obs'].items()};features=encode(obs);seed=42+block
  cached.append(dict(block=block+1,frame=frame,features={k:v.detach().clone() for k,v in features.items()},expert_robot_eef_pose=obs['robot_eef_pose'].detach().clone(),expert_hand_joint=obs['hand_joint'].detach().clone(),expert_actions=sample['action'].detach().clone()))
  usedobs=obs['robot_eef_pose'].clone()
  for i,side in enumerate(['left','right']):usedobs[0,:,i*6:(i+1)*6]=torch.from_numpy(sim[side].history_obs())
  usedhand=torch.from_numpy(hand.copy())[None,None,:].repeat(1,2,1)
  cf=features.copy();cf['robot_eef_pose']=policy.normalizer['robot_eef_pose'].normalize(usedobs).reshape(1,2,12);cf['hand_joint']=policy.normalizer['hand_joint'].normalize(usedhand).reshape(1,2,40)
  pred=predict(cf,seed)
  left=sim['left'].execute(pred);right=sim['right'].execute(np.c_[pred[:,6:12],pred[:,6:12]])
  hand=pred[-1,12:].copy()
  row=dict(block=block+1,dataset_start_frame=frame,mode='all_lowdim_feedback',seed=seed,simulation_time_s=sim['left'].t,input_latest_left_eef=usedobs[0,-1,:6].numpy().tolist(),input_latest_right_eef=usedobs[0,-1,6:].numpy().tolist(),input_latest_hand_joint=usedhand[0,-1].numpy().tolist(),sim_after_left_eef=left.tolist(),sim_after_right_eef=right.tolist(),predicted_last_left_eef=pred[-1,:6].tolist(),predicted_last_right_eef=pred[-1,6:12].tolist(),predicted_last_hand_joint=hand.tolist(),expert_last_left_eef=sample['action'][8,:6].numpy().tolist(),expert_last_right_eef=sample['action'][8,6:12].numpy().tolist())
  rows.append(row)
  if block%4==0 or block==19:print('block',block+1,'demo_z',row['expert_last_left_eef'][2],'all_feedback_z',left[2],'target_z',row['predicted_last_left_eef'][2],flush=True)
  result=dict(scope='Pure CPU ideal joint integration of production CartesianServo for both arms. External chronological teacher images remain unchanged; both EEF streams feed back FK of integrated commands; hand state equals latest predicted target ideally with zero tracking lag and repeated latest history. No hardware, dynamics, contact or image simulation. Mixed-input mechanism test, not calibrated robot simulation.',checkpoint='epoch=0050.ckpt',model_state=key,initial_joint_rad=q.tolist(),velocity_ratio=15,acceleration_ratio=15,policy_hz=30,servo_hz=200,hold_before_each_chunk_s=.16,rows=rows,elapsed_wall_s=time.time()-t0)
  (out/'teacher_vs_all_feedback.json').write_text(json.dumps(result,indent=2))
  torch.save(cached,out/'teacher_features_20blocks.pt')
 print('complete',time.time()-t0,flush=True)
