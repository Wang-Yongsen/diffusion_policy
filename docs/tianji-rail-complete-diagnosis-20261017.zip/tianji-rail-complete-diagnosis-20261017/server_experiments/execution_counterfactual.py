#!/usr/bin/env python3
"""Replay logged requests through offline CartesianServo, with no hardware.

This evaluates the current servo's internal command integration, not physical
robot dynamics. Real trial initial q and measured trajectories were not logged.
We explicitly assume the first demonstration's starting q, and repeat the raw
replay from the configured ready q to assess sensitivity to that assumption.
"""

import argparse
import bisect
import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial.transform import Rotation
from threadpoolctl import threadpool_limits
import zarr


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path("/home/jiyuchen/project/WYS/diffusion_policy"))
    parser.add_argument("--dataset", type=Path, default=Path("/home/jiyuchen/project/WYS/bimanual-teleop/datasets/rail_place3_eef_30hz.zarr"))
    parser.add_argument("--trial", type=Path, default=Path("/home/jiyuchen/.codex/visualizations/2026/10/17/01a14808-7071-71e0-8322-331ee70f25ce/real_trial_analysis/motion-sync-028"))
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project))
    from diffusion_policy.third_party.bimanual_teleop.devices.tianji.model import TianjiKinematics
    from diffusion_policy.third_party.bimanual_teleop.control.arm.servo import CartesianServo
    from diffusion_policy.third_party.bimanual_teleop.types import Pose

    events = [json.loads(line) for line in (args.trial / "trial_0001/events.jsonl").read_text().splitlines()]
    schedules = [event for event in events if event["event"] == "schedule"]
    complete = [event for event in events if event["event"] == "chunk_complete"]
    first_ns, final_ns = schedules[0]["times_ns"][0], complete[-1]["completed_ns"]
    arm_calls = [event for event in events if event["event"] == "submission" and event["kind"] == "arm" and event["started_ns"] <= final_ns]
    action_for_time = {time: np.asarray(action[:6], dtype=float) for chunk in schedules for time, action in zip(chunk["times_ns"], chunk["actions"])}
    index_for_time = {time: index for index, time in enumerate(action_for_time)}
    plan_times = sorted(action_for_time)
    root = zarr.open(str(args.dataset), mode="r")
    demo = root["data/action"][:1000, :6].astype(float)
    demo_q = tuple(float(value) for value in root["data/robot_joint"][0, :7])
    ready_q = tuple(float(value) for value in np.radians([30, -60, -34, -52, 30, 12, 4]))
    kine = TianjiKinematics()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    def as_pose(action):
        return Pose("tianji_left_base", "tianji_left_flange", tuple(action[:3]), tuple(Rotation.from_rotvec(action[3:]).as_quat()))

    def summarize(values):
        return {"min": float(np.min(values)), "median": float(np.median(values)), "p95": float(np.percentile(values, 95)), "max": float(np.max(values)), "mean": float(np.mean(values))}

    reports = {}
    for name, kind, initial_q in [
            ("raw_trial_from_demo_q", "raw", demo_q),
            ("raw_trial_from_ready_q", "raw", ready_q),
            ("demo_targets_with_actual_sync_timing", "demo_sync", demo_q),
            ("demo_targets_continuous_30hz", "demo_continuous", demo_q)]:
        servo = CartesianServo(kine, "left", kine.model, velocity_ratio=15, acceleration_ratio=15)
        servo.reset(initial_q)
        initial_pose = kine.fk("left", initial_q)
        rows, snapshots, previous_ns = [], [], None
        capture_times = iter([0, 1, 2, 3, 5, 8, 10, 15, 20, 25])
        next_capture = next(capture_times, None)
        for call in arm_calls:
            now_ns = call["started_ns"]
            time_s = (now_ns - first_ns) / 1e9
            dt = .005 if previous_ns is None else (now_ns - previous_ns) / 1e9
            previous_ns = now_ns
            if now_ns < first_ns:
                target = initial_pose
                source_index = -1
            elif kind == "raw":
                source_time = call.get("planned_ns")
                if source_time not in action_for_time:
                    target = initial_pose
                    source_index = -1
                else:
                    target = as_pose(action_for_time[source_time])
                    source_index = index_for_time[source_time]
            elif kind == "demo_sync":
                source_index = max(0, bisect.bisect_right(plan_times, now_ns) - 1)
                target = as_pose(demo[source_index])
            else:
                source_index = min(len(demo) - 1, max(0, int(time_s * 30)))
                target = as_pose(demo[source_index])
            step = servo.propose(target, dt, actual_rad=servo.q)
            servo.accept(step)
            joint_margin_deg = np.degrees(np.minimum(np.asarray(step.joints) - servo._lo, servo._hi - np.asarray(step.joints)))
            wrist_margin_deg = 110.5 - np.degrees(1.025 * abs(step.joints[5]) + abs(step.joints[6]))
            row = {"time_s": time_s, "source_action_index": source_index,
                   "requested_x_m": target.position_m[0], "requested_y_m": target.position_m[1], "requested_z_m": target.position_m[2],
                   "internal_x_m": step.pose.position_m[0], "internal_y_m": step.pose.position_m[1], "internal_z_m": step.pose.position_m[2],
                   "position_error_m": step.position_error_m, "orientation_error_rad": step.orientation_error_rad,
                   "progress": step.progress, "limited": bool(step.limited),
                   "minimum_joint_margin_deg": float(np.min(joint_margin_deg)), "nearest_joint_1based": int(np.argmin(joint_margin_deg)) + 1,
                   "wrist_coupling_margin_deg": float(wrist_margin_deg)}
            for index, q in enumerate(step.joints):
                row[f"internal_q{index + 1}_deg"] = float(np.degrees(q))
            if time_s >= 0:
                rows.append(row)
                if next_capture is not None and time_s >= next_capture:
                    snapshots.append(row.copy())
                    next_capture = next(capture_times, None)
        with (args.output_dir / f"{name}.csv").open("w", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
        errors = np.asarray([row["position_error_m"] for row in rows])
        progress = np.asarray([row["progress"] for row in rows])
        margin = np.asarray([row["minimum_joint_margin_deg"] for row in rows])
        reports[name] = {
            "initial_joint_deg": np.degrees(initial_q).tolist(), "initial_xyz_m": list(initial_pose.position_m),
            "samples": len(rows), "duration_s": rows[-1]["time_s"], "final": rows[-1], "snapshots": snapshots,
            "internal_z_m": summarize([row["internal_z_m"] for row in rows]),
            "requested_z_m": summarize([row["requested_z_m"] for row in rows]),
            "position_error_m": summarize(errors),
            "progress": summarize(progress),
            "limited_fraction": float(np.mean([row["limited"] for row in rows])),
            "low_progress_with_position_error_gt_1cm_fraction": float(np.mean((progress < .01) & (errors > .01))),
            "minimum_joint_margin_deg": float(np.min(margin)),
            "minimum_wrist_coupling_margin_deg": min(row["wrist_coupling_margin_deg"] for row in rows),
            "first_crossing_z_s": {str(level): next((row["time_s"] for row in rows if row["internal_z_m"] >= level), None)
                                    for level in (.3, .4, .44, .48)},
        }
        print(json.dumps({"scenario": name, "final_internal_xyz_m": [rows[-1][f"internal_{axis}_m"] for axis in "xyz"],
                          "max_internal_z_m": reports[name]["internal_z_m"]["max"], "position_error_m": reports[name]["position_error_m"],
                          "blocked_fraction": reports[name]["low_progress_with_position_error_gt_1cm_fraction"]}), flush=True)
    def command_roughness(chunks):
        delta = np.diff(chunks[:, :, :3], axis=1)
        distance = np.linalg.norm(delta, axis=-1)
        return {
            "intrablock_xyz_step_mm": summarize(distance * 1000),
            "intrablock_abs_z_step_mm": summarize(np.abs(delta[:, :, 2]) * 1000),
            "intrablock_z_direction_reversal_fraction": float(np.mean(delta[:, :-1, 2] * delta[:, 1:, 2] < 0)),
        }

    report = {
        "scope": "Pure offline official FK + current CartesianServo command integration; no hardware, no robot dynamics. This is not the measured trial trajectory.",
        "assumptions": ["Trial measured initial joint angles are unavailable; raw targets are replayed from demonstration 0 initial q and configured ready q.",
                        "Use actual logged arm submit start timestamps and target selection (planned_ns); measured actual_rad is unavailable, so pass prior internal command q.",
                        "The left arm is replayed independently; no physical collision/contact or impedance/controller dynamics are simulated.",
                        "Demonstration comparisons share actual arm call timestamps; sync selects successive eight demo targets at logged schedule timestamps, continuous selects demo targets at 30 Hz."],
        "trial": str(args.trial), "dataset": str(args.dataset), "model_sha256": kine.model.digest,
        "schedules": len(schedules), "nominal_targets": len(plan_times), "arm_call_samples": len(arm_calls),
        "actual_schedule_duration_s": (final_ns - first_ns) / 1e9, "reports": reports,
        "command_roughness": {
            "raw_trial": command_roughness(np.asarray([chunk["actions"] for chunk in schedules])[:, :, :6]),
            "demo0_same_number_of_steps": command_roughness(demo[:len(plan_times)].reshape(len(schedules), 8, 6)),
        },
    }
    (args.output_dir / "execution_counterfactual.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        main()
