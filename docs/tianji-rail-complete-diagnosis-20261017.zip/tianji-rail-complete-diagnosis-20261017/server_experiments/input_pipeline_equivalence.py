"""Compare training Dataset inputs with deployment preprocessing on identical saved frames."""
import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""
from pathlib import Path
import json
import numpy as np
import torch
import hydra
from threadpoolctl import threadpool_limits

from eval_tianji_rail import load_policy
from diffusion_policy.real_world.tianji_rail_env import preprocess_observation

OUT = Path(__file__).resolve().parent
CKPT = "/home/jiyuchen/project/WYS/diffusion_policy/data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt"
torch.set_num_threads(2)
torch.set_num_interop_threads(2)
rows = []
with threadpool_limits(limits=2):
    policy, cfg, _ = load_policy(CKPT, "cpu")
    train = hydra.utils.instantiate(cfg.task.dataset)
    validation = train.get_validation_dataset()
    locations = {int(start): (train, i) for i, (start, _) in enumerate(train.indices)}
    locations.update({int(start): (validation, i) for i, (start, _) in enumerate(validation.indices)})
    starts = np.r_[0, train.segment_ends[:-1]]
    for source in ("episode_000000", "episode_000003", "episode_000034"):
        segment = train.sources.index(source)
        for offset in (0, 8, 30, 90, 150):
            start = int(starts[segment]) + offset
            dataset, index = locations[start]
            sample = dataset[index]
            raw = {key: np.asarray(train.data[key][start:start + policy.n_obs_steps])
                   for key in cfg.task.shape_meta.obs}
            deployed = preprocess_observation(raw, cfg.task.shape_meta, cfg.task.dataset)
            fields = {}
            for key, expected in sample["obs"].items():
                expected = expected.numpy()
                fields[key] = {
                    "shape": list(expected.shape),
                    "training_dtype": str(expected.dtype),
                    "deployment_dtype": str(deployed[key].dtype),
                    "exactly_equal": bool(np.array_equal(expected, deployed[key])),
                    "max_abs_error": float(np.max(np.abs(expected - deployed[key]))),
                }
                assert fields[key]["exactly_equal"], (source, offset, key)
            row = {"source": source, "offset_frame": offset, "fields": fields}
            if offset == 0:
                with torch.inference_mode():
                    torch.manual_seed(42)
                    from_train = policy.predict_action({key: value.unsqueeze(0) for key, value in sample["obs"].items()})["action"].numpy()
                    torch.manual_seed(42)
                    from_deployment = policy.predict_action({key: torch.from_numpy(value).unsqueeze(0) for key, value in deployed.items()})["action"].numpy()
                row["prediction_max_abs_difference"] = float(np.max(np.abs(from_train - from_deployment)))
                assert row["prediction_max_abs_difference"] == 0
            rows.append(row)
            print(json.dumps({"source": source, "offset": offset, "all_fields_exact": True,
                              "prediction_max_abs_difference": row.get("prediction_max_abs_difference")}), flush=True)
    report = {
        "checkpoint": CKPT,
        "windows": len(rows),
        "input_fields_per_window": 5,
        "every_input_element_equal": True,
        "prediction_pairs_compared": 3,
        "all_prediction_pairs_max_abs_difference": 0,
        "scope": "Same saved RGB/state arrays through Dataset vs deployment preprocess_observation. Tests preprocessing only, not live camera pose, measured state, timestamp alignment or physical tracking.",
        "rows": rows,
    }
    (OUT / "input_pipeline_equivalence.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
