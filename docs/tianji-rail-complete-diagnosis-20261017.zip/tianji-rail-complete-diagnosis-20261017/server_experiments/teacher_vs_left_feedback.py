"""No devices: ideal joint integration of existing CartesianServo; teacher images are externally replayed."""
import os,time,json
os.environ['CUDA_VISIBLE_DEVICES']=''
from pathlib import Path
import numpy as np,torch,hydra
from scipy.spatial.transform import Rotation
from threadpoolctl import threadpool_limits
from eval_tianji_rail import load_policy
from diffusion_policy.third_party.bimanual_teleop.devices.tianji.model import TianjiKinematics
from diffusion_policy.third_party.bimanual_teleop.control.arm.servo import CartesianServo
from diffusion_policy.third_party.bimanual_teleop.types import Pose
out=Path(__file__).parent;torch.set_num_threads(2);torch.set_num_interop_threads(2);t0=time.time()
kin=TianjiKinematics()
def vector(pose):return np.r_[pose.position_m,Rotation.from_quat(pose.orientation_xyzw).as_rotvec()]
def goal(v):return Pose('tianji_left_base','tianji_left_flange',tuple(v[:3]),tuple(Rotation.from_rotvec(v[3:6]).as_quat()))
class Integrator:
 def __init__(self,q):
  self.servo=CartesianServo(kin,'left',kin.model,velocity_ratio=15,acceleration_ratio=15);self.servo.reset(tuple(q));self.t=0.;self.history=[(0.,vector(kin.fk('left',tuple(q))))];self.lastgoal=kin.fk('left',tuple(q));self.samples=[]
 def advance(self,target,duration):
  remaining=float(duration)
  while remaining>1e-9:
   dt=min(.005,remaining);step=self.servo.propose(target,dt);self.servo.accept(step);self.t+=dt
   self.history.append((self.t,vector(step.pose)));self.samples.append((self.t,step.position_error_m,step.orientation_error_rad,step.limited,step.progress));remaining-=dt
  self.lastgoal=target
 def history_obs(self):
  ts=np.array([x[0] for x in self.history]);vv=np.array([x[1] for x in self.history]);query=[max(0.,self.t-1/30),self.t]
  vals=[]
  for t in query:
   idx=int(np.searchsorted(ts,t,side='left'));idx=min(idx,len(ts)-1)
   if idx==0 or ts[idx]==t:vals.append(vv[idx]);continue
   lower=idx-1;f=(t-ts[lower])/(ts[idx]-ts[lower]);v=vv[lower]+f*(vv[idx]-vv[lower]);
   from scipy.spatial.transform import Slerp
   v[3:6]=Slerp([0.,1.],Rotation.from_rotvec(vv[[lower,idx],3:6]))([f]).as_rotvec()[0];vals.append(v)
  return np.array(vals,dtype=np.float32)
 def execute(self,actions):
  self.advance(self.lastgoal,.16)
  for a in actions:self.advance(goal(a[:6]),1/30)
  return vector(kin.fk('left',self.servo.q))
with threadpool_limits(limits=2),torch.inference_mode():
 policy,cfg,key=load_policy('data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt','cpu');ds=hydra.utils.instantiate(cfg.task.dataset);lookup={int(s):i for i,(s,_) in enumerate(ds.indices)}
 q=np.asarray(ds.data['robot_joint'][0,:7],dtype=float);sim={'teacher':Integrator(q),'left_feedback':Integrator(q)};rows=[]
 camera_rows=[];enc=policy.obs_encoder
 assert enc.obs_nets['robot_eef_pose'] is None
 def encode(obs):
  nobs=policy.normalizer.normalize(obs);feats={}
  for k in enc.obs_shapes:
   x=nobs[k].reshape(-1,*nobs[k].shape[2:])
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_in(x)
   if enc.obs_nets[k] is not None:
    x=enc.obs_nets[k](x)
    if enc.activation is not None:x=enc.activation(x)
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_out(x)
   feats[k]=x.reshape(1,2,-1)
  return feats
 def predict(feats,seed):
  cond=torch.cat([feats[k] for k in enc.obs_shapes],dim=-1);zeros=torch.zeros((1,16,52));torch.manual_seed(seed);policy.reset()
  sample=policy.conditional_sample(zeros,torch.zeros_like(zeros,dtype=torch.bool),cond=cond,**policy.kwargs)
  return policy.normalizer['action'].unnormalize(sample)[0,1:9].cpu().numpy()
 for block in range(20):
  frame=block*8;sample=ds[lookup[frame]];obs={k:v.unsqueeze(0) for k,v in sample['obs'].items()};features=encode(obs);seed=42+block
  for mode in ['teacher','left_feedback']:
   feats=features.copy();usedobs=obs['robot_eef_pose'].clone()
   if mode=='left_feedback':
    usedobs[0,:,:6]=torch.from_numpy(sim[mode].history_obs());feats['robot_eef_pose']=policy.normalizer['robot_eef_pose'].normalize(usedobs).reshape(1,2,12)
   pred=predict(feats,seed);before=vector(kin.fk('left',sim[mode].servo.q));after=sim[mode].execute(pred)
   row=dict(block=block+1,dataset_start_frame=frame,demo_latest_observation_s=(frame+1)/30,mode=mode,seed=seed,simulation_time_s=sim[mode].t,input_latest_left_eef=usedobs[0,-1,:6].numpy().tolist(),sim_before_left_eef=before.tolist(),sim_after_left_eef=after.tolist(),predicted_first_left_eef=pred[0,:6].tolist(),predicted_last_left_eef=pred[-1,:6].tolist(),predicted_mean_left_eef=pred[:,:6].mean(0).tolist(),expert_last_left_eef=sample['action'][8,:6].numpy().tolist(),expert_latest_observed_left_eef=sample['obs']['robot_eef_pose'][-1,:6].numpy().tolist())
   rows.append(row)
  if block in [0,4,11,19]:
   original=predict(features,seed)
   for history_kind,slot in [('repeat_oldest',0),('repeat_newest',1)]:
    cf=features.copy();cf['camera_1']=features['camera_1'][:,slot:slot+1,:].repeat(1,2,1);cp=predict(cf,seed)
    camera_rows.append(dict(block=block+1,dataset_start_frame=frame,history_condition=history_kind,seed=seed,last_xyz_shift_mm=((cp[-1,:3]-original[-1,:3])*1000).tolist(),last_xyz_shift_norm_mm=float(np.linalg.norm(cp[-1,:3]-original[-1,:3])*1000),last_rotation_shift_deg=float(np.rad2deg((Rotation.from_rotvec(cp[-1,3:6])*Rotation.from_rotvec(original[-1,3:6]).inv()).magnitude()))))
  if block%4==0 or block==19:

   print('block',block+1,'demo_z',rows[-1]['expert_last_left_eef'][2],'teacher_sim_z',rows[-2]['sim_after_left_eef'][2],'feedback_sim_z',rows[-1]['sim_after_left_eef'][2],'teacher_target_z',rows[-2]['predicted_last_left_eef'][2],'feedback_target_z',rows[-1]['predicted_last_left_eef'][2],flush=True)
  result=dict(scope='Pure CPU ideal joint integration of production CartesianServo; no hardware, no dynamics/contact/camera simulation. Both conditions receive chronological teacher images, teacher right EEF and teacher hand state. Only the feedback condition replaces left EEF with FK of integrated servo commands. This is a mixed-input mechanism intervention, not a calibrated robot simulation.',checkpoint='epoch=0050.ckpt',model_state=key,initial_joint_rad=q.tolist(),initial_fk=sim['teacher'].history[0][1].tolist(),initial_dataset_left_eef=np.asarray(ds.data['robot_eef_pose'][0,:6]).tolist(),velocity_ratio=15,acceleration_ratio=15,policy_hz=30,servo_hz=200,hold_before_each_chunk_s=.16,rows=rows,camera1_only_counterfactuals=camera_rows,elapsed_wall_s=time.time()-t0)
  (out/'teacher_vs_left_feedback.json').write_text(json.dumps(result,indent=2))
 print('complete',time.time()-t0,flush=True)
