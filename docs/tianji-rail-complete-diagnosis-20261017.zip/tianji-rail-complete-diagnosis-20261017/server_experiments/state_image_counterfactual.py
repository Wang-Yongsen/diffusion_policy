"""CPU-only, feature-cached paired sensitivity analysis; mixed observations are counterfactual."""
import os,time,json
os.environ['CUDA_VISIBLE_DEVICES']=''
from pathlib import Path
import numpy as np,torch,hydra
from threadpoolctl import threadpool_limits
from scipy.spatial.transform import Rotation
from eval_tianji_rail import load_policy
out=Path(__file__).resolve().parent; checkpoint='data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt'
torch.set_num_threads(2);torch.set_num_interop_threads(2)
t0=time.time();rows=[];fidelity=[];cache={}
def geodesic_deg(x,y):
 return float(np.rad2deg((Rotation.from_rotvec(x).inv()*Rotation.from_rotvec(y)).magnitude()))
with threadpool_limits(limits=2),torch.inference_mode():
 print('load',flush=True);policy,cfg,key=load_policy(checkpoint,'cpu');ds=hydra.utils.instantiate(cfg.task.dataset);vds=ds.get_validation_dataset();starts=np.r_[0,ds.segment_ends[:-1]]
 lookup={int(s):i for i,(s,_) in enumerate(ds.indices)};vlookup={int(s):i for i,(s,_) in enumerate(vds.indices)}
 print('loaded',time.time()-t0,flush=True)
 def modality_features(obs):
  nobs=policy.normalizer.normalize(obs);enc=policy.obs_encoder;features={}
  for k in enc.obs_shapes:
   x=nobs[k].reshape(-1,*nobs[k].shape[2:])
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_in(x)
   if enc.obs_nets[k] is not None:
    x=enc.obs_nets[k](x)
    if enc.activation is not None:x=enc.activation(x)
   if enc.obs_randomizers[k] is not None:x=enc.obs_randomizers[k].forward_out(x)
   features[k]=x.reshape(1,2,-1)
  return features
 def predict_features(features):
  cond=torch.cat([features[k] for k in policy.obs_encoder.obs_shapes],dim=-1)
  shape=(1,policy.horizon,policy.action_dim)
  condition=torch.zeros(shape,dtype=policy.dtype,device='cpu');mask=torch.zeros_like(condition,dtype=torch.bool)
  torch.manual_seed(42);policy.reset()
  n=policy.conditional_sample(condition,mask,cond=cond,**policy.kwargs)
  return policy.normalizer['action'].unnormalize(n)[0,policy.n_obs_steps-1:policy.n_obs_steps-1+policy.n_action_steps].cpu().numpy()
 for source in ['episode_000000','episode_000034']:
  seg=ds.sources.index(source);base=int(starts[seg]);split='val' if ds.val_mask[seg] else 'train'
  for sec in [0,1,3,5]:
   frame=base+30*sec; sample=(ds[lookup[frame]] if frame in lookup else vds[vlookup[frame]])
   obs={k:v.unsqueeze(0) for k,v in sample['obs'].items()};feats=modality_features(obs);pred=predict_features(feats)
   cache[(source,sec)]=dict(obs=obs,features=feats,pred=pred,target=sample['action'][1:9].numpy(),split=split,frame=frame)
   print('encoded',source,sec,'z_last_mm',float(pred[-1,2]*1000),flush=True)
 # Recheck feature caching against unmodified public predict_action for a baseline and an actual mixed input.
 for test in ['baseline','mixed']:
  c=cache[('episode_000034',0)];other=cache[('episode_000034',5)]
  obs=c['obs'].copy();feats=c['features'].copy()
  if test=='mixed':
   for k in feats:
    if k.startswith('camera_'):obs[k]=other['obs'][k];feats[k]=other['features'][k]
  torch.manual_seed(42);policy.reset();public=policy.predict_action(obs)['action'][0].cpu().numpy();cached=predict_features(feats)
  error=float(np.max(np.abs(public-cached)));fidelity.append(dict(test=test,max_abs_action_difference=error));assert error<1e-6
 for source in ['episode_000000','episode_000034']:
  for sec in [0,1,3,5]:
   c=cache[(source,sec)];other_sec=5 if sec<=1 else 0;other=cache[(source,other_sec)]
   for kind in ['baseline','swap_images','swap_state','stationary_history']:
    features=c['features'].copy()
    if kind in ['swap_images','swap_state']:
     for k in features:
      if (k.startswith('camera_')) == (kind=='swap_images'):features[k]=other['features'][k]
    elif kind=='stationary_history':features={k:v[:,-1:].repeat(1,2,1) for k,v in features.items()}
    pred=c['pred'] if kind=='baseline' else predict_features(features)
    current=(other if kind=='swap_state' else c)['obs']['robot_eef_pose'][0,-1].numpy()
    target=c['target'];orig=c['pred'];alt=other['pred']
    row=dict(source=source,split=c['split'],base_time_s=sec,alternate_time_s=other_sec,condition=kind,seed=42,num_inference_steps=policy.num_inference_steps,base_frame=c['frame'],input_current_left_xyz_mm=(current[:3]*1000).tolist(),input_current_left_rotvec_rad=current[3:6].tolist(),base_current_left_xyz_mm=(c['obs']['robot_eef_pose'][0,-1,:3].numpy()*1000).tolist(),base_current_left_rotvec_rad=c['obs']['robot_eef_pose'][0,-1,3:6].numpy().tolist(),expert_last_left_xyz_mm=(target[-1,:3]*1000).tolist(),expert_last_left_rotvec_rad=target[-1,3:6].tolist(),pred_last_left_xyz_mm=(pred[-1,:3]*1000).tolist(),pred_mean_left_xyz_mm=(pred[:,:3].mean(axis=0)*1000).tolist(),pred_last_left_rotvec_rad=pred[-1,3:6].tolist(),pred_mean_left_rotvec_rad=pred[:,3:6].mean(axis=0).tolist(),pred_last_delta_from_input_current_mm=((pred[-1,:3]-current[:3])*1000).tolist(),pred_last_xyz_shift_from_baseline_mm=((pred[-1,:3]-orig[-1,:3])*1000).tolist(),pred_last_rotation_shift_from_baseline_deg=geodesic_deg(orig[-1,3:6],pred[-1,3:6]),pred_last_position_error_vs_base_expert_mm=float(np.linalg.norm(pred[-1,:3]-target[-1,:3])*1000),pred_last_rotation_error_vs_base_expert_deg=geodesic_deg(pred[-1,3:6],target[-1,3:6]),alternate_baseline_last_left_xyz_mm=(alt[-1,:3]*1000).tolist(),alternate_baseline_last_left_rotvec_rad=alt[-1,3:6].tolist(),predicted_left_eef=pred[:,:6].tolist())
    rows.append(row)
 print('fidelity',fidelity,flush=True)
 report=dict(checkpoint=checkpoint,model_state=key,device='cpu',torch_threads=2,seed=42,conditions='baseline; swap all 3 RGB streams with same-episode other-stage images; swap robot_eef_pose+hand_joint only; repeat newest frame for both history times across all modalities',limitation='Mismatched image/state inputs are sensitivity probes, not physically realized scenes. No observations from the failing trial were available. This cannot individually prove its root cause.',fidelity=fidelity,seconds=time.time()-t0,rows=rows)
 (out/'state_image_counterfactual.json').write_text(json.dumps(report,indent=2))
 for source in ['episode_000000','episode_000034']:
  for sec in [0,1,3,5]:
   group=[r for r in rows if r['source']==source and r['base_time_s']==sec]
   print(source,sec,[dict(condition=r['condition'],z_mm=round(r['pred_last_left_xyz_mm'][2],2),dy_rad=round(r['pred_last_left_rotvec_rad'][1],3),delta_z_mm=round(r['pred_last_delta_from_input_current_mm'][2],2),rot_shift_deg=round(r['pred_last_rotation_shift_from_baseline_deg'],2)) for r in group],flush=True)
 print('complete',time.time()-t0,flush=True)
