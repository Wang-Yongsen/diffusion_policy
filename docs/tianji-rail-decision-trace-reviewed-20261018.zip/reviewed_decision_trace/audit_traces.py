from pathlib import Path
import json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'/home/jiyuchen/project/WYS/diffusion_policy')
from diffusion_policy.third_party.bimanual_teleop.devices.tianji.model import TianjiKinematics

ROOT=Path('/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1')
BASE=ROOT/'received_decision_trace_20261018/tianji-rail-decision-trace-20261018'
OUT=ROOT/'artifacts/decision_trace_review_20261018';OUT.mkdir(parents=True,exist_ok=True)
kine=TianjiKinematics();result={};arrays={}
def stats(a):
 a=np.asarray(a);a=a[np.isfinite(a)]
 return dict(n=len(a),median=float(np.median(a)),p95=float(np.percentile(a,95)),max=float(np.max(a))) if len(a) else None
for run in ['replay','closed']:
 p=BASE/f'motion/{run}/trial_0001';d=np.load(p/'trace_decisions.npz',allow_pickle=False);c=np.load(p/'trace_commands.npz',allow_pickle=False);f=np.load(p/'trace_feedback.npz',allow_pickle=False);h=np.load(p/'trace_hands.npz',allow_pickle=False);m=json.loads((p/'trace_meta.json').read_text());e=[json.loads(x) for x in (p/'events.jsonl').read_text().splitlines()]
 # Only the known server-side kinematics implementation is invoked; no supplied scripts or devices are used.
 ft=f['received_ns'];fq=f['q'][:,0];xyz=np.array([kine.fk('left',tuple(q)).position_m for q in fq]);cx=np.array([kine.fk('left',tuple(q)).position_m for q in f['controller_target'][:,0]])
 def pose_at(t):
  if t<ft[0] or t>ft[-1]: return None
  q=tuple(np.interp(t,ft,fq[:,j]) for j in range(7));return np.array(kine.fk('left',q).position_m)
 ds=[]
 for i in range(len(d['present'])):
  anchor=int(d['anchor_ns'][i]);start=int(d['started_ns'][i]);end=int(d['returned_ns'][i]);a=pose_at(anchor);s=pose_at(start);b=pose_at(end);window=(ft>=anchor)&(ft<=end)
  ds.append(dict(index=i,anchor_ns=anchor,started_ns=start,returned_ns=end,anchor_to_return_ms=(end-anchor)/1e6,started_to_return_ms=(end-start)/1e6,actual_at_anchor_xyz_mm=(a*1000).tolist() if a is not None else None,actual_at_return_xyz_mm=(b*1000).tolist() if b is not None else None,anchor_to_return_endpoint_displacement_mm=float(np.linalg.norm(b-a)*1000) if a is not None and b is not None and end>=anchor else None,started_to_return_endpoint_displacement_mm=float(np.linalg.norm(b-s)*1000) if s is not None and b is not None and end>=start else None,max_excursion_from_anchor_mm=float(np.max(np.linalg.norm(xyz[window]-a,axis=1))*1000) if a is not None and window.any() else None,input_left_xyz_mm=(d['robot_eef_pose'][i,-1,:3]*1000).tolist(),last_requested_left_xyz_mm=(d['actions'][i,-1,:3]*1000).tolist()))
 valid=c['accepted']&c['q_cmd_present'].all(axis=1)&c['requested_present'].all(axis=1)&c['command_fk_present'].all(axis=1)
 reqgap=np.linalg.norm(c['requested_xyz'][valid,0]-c['command_fk_xyz'][valid,0],axis=1)*1000
 sampled=[];mgap=[]
 for i in np.flatnonzero(valid):
  t=int(c['receipt_ns'][i]);ix=np.searchsorted(ft,t);ix=min(max(ix,1),len(ft)-1);idx=ix if abs(ft[ix]-t)<abs(ft[ix-1]-t) else ix-1
  if abs(ft[idx]-t)<=20e6:mgap.append(np.linalg.norm(c['command_fk_xyz'][i,0]-xyz[idx])*1000)
 for i in np.flatnonzero(valid)[::max(1,int(valid.sum()/20))]:
  recomputed=np.array(kine.fk('left',tuple(c['q_cmd'][i,0])).position_m);sampled.append(np.linalg.norm(recomputed-c['command_fk_xyz'][i,0])*1000)
 target_qdiff=f['controller_target']-f['q'];origin=int(d['anchor_ns'][0]);last=int(d['returned_ns'][-1]);active=(ft>=origin)&(ft<=last+300_000_000)
 res=dict(trace_valid=m['valid'],trace_invalid_reason=m['invalid_reason'],dropped=m['dropped'],present_decisions=int(d['present'].sum()),commands_with_full_arm_details=int(valid.sum()),command_rows_without_accepted_full_details=int((~valid).sum()),orphan_row_note='False accepted on rows lacking command details is not evidence of a rejected arm command; most such rows contain SDK receipt metadata only.',hand_commands=int(len(h['accepted'])),hand_commands_accepted=int(h['accepted'].sum()),request_to_command_fk_mm=stats(reqgap),command_fk_to_nearby_actual_mm=stats(mgap),sampled_command_fk_recompute_mm=stats(sampled),controller_target_minus_actual_joint_rad=stats(abs(target_qdiff).ravel()),controller_target_exact_equal_fraction=float(np.mean(target_qdiff==0)),controller_target_fk_minus_actual_fk_mm=stats(np.linalg.norm(cx[active]-xyz[active],axis=1)*1000),limited_fraction_left=float(c['limited'][valid,0].mean()),progress_left=stats(c['progress'][valid,0]),anchor_to_return_actual_displacement_mm=stats([x['anchor_to_return_endpoint_displacement_mm'] for x in ds if x['anchor_to_return_endpoint_displacement_mm'] is not None]),started_to_return_actual_displacement_mm=stats([x['started_to_return_endpoint_displacement_mm'] for x in ds if x['started_to_return_endpoint_displacement_mm'] is not None]),decisions=ds)
 if run=='replay':res['first_replay_timing_note']='Decision 0 was inferred before start approach; its returned_ns precedes real-anchor by about 7.8 seconds and is not an inference-time motion comparison. Later real anchors are captured after inference starts, so anchor-to-return omits part of the inference interval.'
 result[run]=res;arrays[run]=dict(d=d,actual=xyz,ft=ft)

r=arrays['replay']['d'];cl=arrays['closed']['d'];n=min(len(r['present']),len(cl['present']));diff=(cl['actions'][:n,:,:3]-r['actions'][:n,:,:3])*1000
comparison=[]
for i in range(n):
 ra=np.array(result['replay']['decisions'][i]['actual_at_anchor_xyz_mm']);ca=np.array(result['closed']['decisions'][i]['actual_at_anchor_xyz_mm'])
 comparison.append(dict(index=i,closed_minus_replay_mean_requested_xyz_mm=diff[i].mean(axis=0).tolist(),closed_minus_replay_last_requested_xyz_mm=diff[i,-1].tolist(),action_xyz_difference_mm=stats(np.linalg.norm(diff[i],axis=1)),closed_minus_replay_actual_at_anchor_mm=(ca-ra).tolist(),actual_at_anchor_distance_mm=float(np.linalg.norm(ca-ra))))
result['cross_run_comparison']=comparison
result['limitations']=['Both full traces are invalid because their status buffer overflowed. Early existing streams can support limited numeric observations, not a claim of complete valid traces.','The first 48 closed decisions are preserved; final 16 observation windows are absent.','controller_target is the official m_FB_Joint_Cmd field according to the hash-matched server driver/SDK decode, and numerically differs from actual. This does not prove it is an echo of the externally sent q_cmd or prove physical execution.','Cross-run first action comparisons differ in full inputs/RNG context and are not controlled field replacements; use replay paired inference for causal localization.']
(OUT/'trace_independent_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
for ax,axis in zip(axs[0],[1,2]):
 for run,color in [('replay','#1766a4'),('closed','#d46a1e')]:
  rs=result[run]['decisions'][:8];vals=np.array([x['actual_at_anchor_xyz_mm'] for x in rs]);ax.plot(np.arange(len(vals)),vals[:,axis],'-o',color=color,label=f'{run}: measured FK at observation anchor')
 ax.set_ylabel(f'Left {"Y down" if axis==1 else "Z outward"} (mm)');ax.set_xlabel('Decision index (0-based)');ax.legend(fontsize=8);ax.grid(alpha=.2)
for run,color in [('replay','#1766a4'),('closed','#d46a1e')]:
 ds=result[run]['decisions'];ys=[x['started_to_return_endpoint_displacement_mm'] for x in ds];axs[1,0].plot(range(len(ys)),ys,'-o',markersize=3,color=color,label=run)
axs[1,0].set_ylabel('Measured displacement while inference runs (mm)');axs[1,0].set_xlabel('Decision index (0-based)');axs[1,0].legend();axs[1,0].grid(alpha=.2)
axs[1,1].plot(range(n),[x['closed_minus_replay_mean_requested_xyz_mm'][1] for x in comparison],'-o',color='#8044a3',label='Mean requested Y difference')
axs[1,1].plot(range(n),[x['closed_minus_replay_actual_at_anchor_mm'][1] for x in comparison],'-o',color='#23824d',label='Measured Y difference at each anchor');axs[1,1].axhline(0,color='gray',lw=.7);axs[1,1].set_ylabel('Closed minus replay (mm)');axs[1,1].set_xlabel('Decision index (0-based)');axs[1,1].legend(fontsize=8);axs[1,1].grid(alpha=.2)
fig.suptitle('Independent trace check: early prediction differences precede accumulated path error\nFull traces invalid due status overflow; closed observation windows preserved only for indices 0–47.',fontsize=12)
fig.savefig(OUT/'earliest_divergence.png',dpi=180)
for run in ['replay','closed']:
 print(run,{k:v for k,v in result[run].items() if k not in ['decisions','first_replay_timing_note']});print('first5',result[run]['decisions'][:5])
print('FIRST5_COMPARISON',comparison[:5])
