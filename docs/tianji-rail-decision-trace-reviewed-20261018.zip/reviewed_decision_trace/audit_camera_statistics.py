"""Read-only camera statistics on uploaded observations and server training zarr."""
from pathlib import Path
import json
import numpy as np
import cv2
import zarr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path('/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1/received_decision_trace_20261018/tianji-rail-decision-trace-20261018')
OUT = Path(__file__).parent
DATASET = '/home/jiyuchen/project/WYS/bimanual-teleop/datasets/rail_place3_eef_30hz.zarr'
z = zarr.open(DATASET, mode='r')
ends = np.asarray(z['meta/segment_ends'])
starts = np.r_[0, ends[:-1]]
segments = z['meta'].attrs['segments']
report = {'scope': 'Brightness alone is a descriptive statistic, not a causal attribution.', 'dataset': DATASET, 'cameras': {}}

def stats(a):
    g = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY)
    return {'rgb_mean': float(a.mean()), 'rgb_channels': a.mean(axis=(0,1)).tolist(),
            'gray_mean': float(g.mean()), 'gray_std': float(g.std()),
            'gray_below_32_fraction': float((g < 32).mean()),
            'gray_above_245_fraction': float((g > 245).mean()),
            'gray_top_half_mean': float(g[:240].mean()),
            'gray_bottom_half_mean': float(g[240:].mean())}

with np.load(ROOT/'motion/replay/trial_0001/trace_decisions.npz', allow_pickle=False) as f:
    for cam in ['camera_0','camera_1','camera_2']:
        demo = f[cam][:, -1]
        real = f['real_'+cam][:, -1]
        initial_means = []
        for start, seg in zip(starts, segments):
            img = z['data/'+cam][int(start)]
            initial_means.append({'source': seg.get('source_episode', seg.get('source', '?')),
                                  'start': int(start), **stats(img)})
        initial_start = int(f['window_start'][0])
        report['cameras'][cam] = {
            'demo_decision0': stats(demo[0]), 'real_decision0': stats(real[0]),
            'dataset_initial_frames': initial_means,
            'dataset_initial_rgb_mean_min_median_max': [float(v) for v in np.quantile([s['rgb_mean'] for s in initial_means], [0,.5,1])],
            'demo24_rgb_means': demo.mean(axis=(1,2,3)).tolist(),
            'real24_rgb_means': real.mean(axis=(1,2,3)).tolist(),
            'demo_trace_first_window_equals_server_zarr': bool(np.array_equal(f[cam][0], z['data/'+cam][initial_start:initial_start+2]))}

fig, axes = plt.subplots(2,3, figsize=(13,7))
for col, cam in enumerate(['camera_0','camera_1','camera_2']):
    r = report['cameras'][cam]
    ax = axes[0,col]
    ax.hist([s['rgb_mean'] for s in r['dataset_initial_frames']], bins=10, color='#94a3b8')
    ax.axvline(r['demo_decision0']['rgb_mean'], color='#2563eb', label='Reference frame')
    ax.axvline(r['real_decision0']['rgb_mean'], color='#ea580c', label='Real frame')
    ax.set_title(cam+' initial frames from 41 demonstrations')
    ax.set_xlabel('Mean RGB value'); ax.set_ylabel('Demonstrations')
    ax.legend(fontsize=8)
    ax = axes[1,col]
    ax.plot(r['demo24_rgb_means'], color='#2563eb', label='Reference')
    ax.plot(r['real24_rgb_means'], color='#ea580c', label='Real during successful replay')
    ax.set_xlabel('Decision index (zero-based)'); ax.set_ylabel('Mean RGB value')
    ax.legend(fontsize=8); ax.grid(alpha=.2)
fig.suptitle('Global brightness is insufficient to identify the visual cause', fontsize=14)
fig.tight_layout()
fig.savefig(OUT/'camera_brightness_statistics.png', dpi=150)
(OUT/'camera_statistics.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps({cam: {k:v for k,v in r.items() if k in ['demo_decision0','real_decision0','dataset_initial_rgb_mean_min_median_max','demo_trace_first_window_equals_server_zarr']} for cam,r in report['cameras'].items()}, ensure_ascii=False))
