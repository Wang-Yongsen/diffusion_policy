"""Hash-checked recording patch installer. Defaults to inspection, never starts hardware."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import os
import shutil
import tempfile
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect(project, bundle):
    manifest = json.loads((bundle / 'patch_manifest.json').read_text())
    rows = []
    for item in manifest['files']:
        source = bundle / 'source' / item['path']
        target = project / item['path']
        if digest(source) != item['patched_sha256']:
            raise ValueError('Bundle content mismatch: ' + item['path'])
        ast.parse(source.read_text(), filename=str(source))
        current = digest(target) if target.is_file() else None
        state = 'already_patched' if current == item['patched_sha256'] else (
            'ready' if current == item['base_sha256'] else 'conflict')
        rows.append({**item, 'current_sha256': current, 'state': state})
    return rows


def install(project, bundle, rows):
    if any(row['state'] == 'conflict' for row in rows):
        raise ValueError('Local changes or missing files: inspect and merge; no files installed')
    if all(row['state'] == 'already_patched' for row in rows):
        return {'installed': [], 'backup': None}
    backup_root = project / '.diagnosis-backups'
    backup_root.mkdir(exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix=time.strftime('%Y%m%d-%H%M%S-'), dir=backup_root))
    changed = []
    try:
        for row in rows:
            if row['state'] == 'already_patched':
                continue
            relative = row['path']
            target = project / relative
            if digest(target) != row['base_sha256']:
                raise ValueError('File changed after preflight: ' + relative)
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
            descriptor, name = tempfile.mkstemp(prefix='.diagnosis-', dir=target.parent)
            os.close(descriptor)
            temporary = Path(name)
            try:
                shutil.copy2(bundle / 'source' / relative, temporary)
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
            changed.append(relative)
    except BaseException:
        for relative in reversed(changed):
            shutil.copy2(backup / relative, project / relative)
        raise
    return {'installed': changed, 'backup': str(backup) if changed else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True, type=Path)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    rows = inspect(args.project.resolve(), bundle)
    report = {'mode': 'apply' if args.apply else 'inspection_only', 'files': rows}
    if args.apply:
        report.update(install(args.project.resolve(), bundle, rows))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 2 if any(row['state'] == 'conflict' for row in rows) else 0


if __name__ == '__main__':
    raise SystemExit(main())
