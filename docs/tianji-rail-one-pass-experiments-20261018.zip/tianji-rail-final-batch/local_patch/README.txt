记录与对照流程修复，未在本机机器人部署。

默认只读检查：
python local_patch/apply_local_patch.py --project /home/yuchen/project/diffusion_policy

全部基线hash匹配后应用；有差异则由本地AI保留现有修改进行合并：
python local_patch/apply_local_patch.py --project /home/yuchen/project/diffusion_policy --apply

本包修改5文件，修复日志溢出、收据设备隔离/三态、跨trial缓存与并发、采图时间、正式首块重算和显式batch-seed；增加回放skip-approach。其余运动约束不修改。
V/S与统一初始化的本机adapter仍需本地AI实现、冻结真实参数并完成完整影子预检。补丁的CLI并不等于完整13段硬件启动器。

测试：13个pure trace测试通过，4项安装器检查通过。所有5文件AST语法通过。图像复制微基准在tests内；它不含现场线程竞争，不能当作实际控制时延上界。
