"""Single-thread saved-observation copy benchmark; no hardware imports/calls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import time
import numpy as np

BASE=Path(__file__).resolve().parents[1]
SOURCE=BASE/'source/diffusion_policy/real_world/decision_trace.py'
SOURCE_HASH=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('benchmark_pure_decision_trace',SOURCE)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

def observation(value):
    obs={k:np.full((2,480,640,3),value,dtype=np.uint8) for k in m.CAMERAS}
    obs.update(robot_eef_pose=np.full((2,12),.2,dtype=np.float32),
               hand_joint=np.full((2,40),.1,dtype=np.float32))
    return obs

demo,real=observation(101),observation(117)
actions=np.full((8,52),.1,dtype=np.float64)
rng={'device':'cpu','cpu':np.arange(5056,dtype=np.uint8),'cuda':None}
t=m.SessionTrace(decision_capacity=12,feedback_capacity=8,command_capacity=8,hand_capacity=8,status_capacity=8)
allocation_started=time.perf_counter_ns()
t.allocate_decisions(demo,8,capture_real=True)
allocation_ms=(time.perf_counter_ns()-allocation_started)/1e6
times={}
for phase in ('first_write_after_allocation_pretouch','reuse_previously_written_rows'):
    t.begin_trial()
    samples=[]
    for i in range(12):
        started=time.perf_counter_ns()
        row=t.store_decision(obs=demo,alignment={'camera_ns':[1,2]},anchor_ns=2,actions=actions,
            started_ns=3,observed_ns=4,preprocessed_ns=5,inputs_ready_ns=6,returned_ns=7,
            rng=rng,real_obs=real,real_alignment={'camera_ns':[9,10]},real_anchor_ns=10,window_start=i*8,
            live_capture_started_ns=8,live_capture_returned_ns=11)
        elapsed=(time.perf_counter_ns()-started)/1e6
        assert row==i
        samples.append(elapsed)
    times[phase]={'n':12,'samples_ms':samples,'first_call_ms':samples[0],
        'min_ms':float(np.min(samples)),'median_ms':float(np.median(samples)),
        'p95_ms':float(np.quantile(samples,.95)),'max_ms':float(np.max(samples))}

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SOURCE_HASH,'Source changed during benchmark'
report={'source':str(SOURCE),'source_sha256':SOURCE_HASH,
        'input_shape':[2,480,640,3],'camera_count':3,'capture_real':True,'n_calls_total':24,
        'image_bytes_copied_per_store':sum(x.nbytes for x in demo.values() if x.dtype==np.uint8)*2,
        'allocation_and_page_pretouch_ms':allocation_ms,
        'allocation_image_bytes_touched':sum(x.nbytes for x in t.images.values())+sum(x.nbytes for x in t.real_images.values()),
        'phases':times,
        'limitations':['Isolated single-thread microbenchmark, without servo/feedback contention.',
                       'The patch explicitly touches image pages during allocation. That setup cost is measured separately; both copy phases therefore use resident pages.',
                       'No image generation/preprocessing/encoding, NPZ compression or flush is timed.',
                       'These measurements do not establish physical real-time latency or safety.']}
(BASE/'tests/decision_copy_benchmark.json').write_text(json.dumps(report,indent=2))
for phase,r in times.items():print(phase,'median_ms',r['median_ms'],'p95_ms',r['p95_ms'],'max_ms',r['max_ms'])
