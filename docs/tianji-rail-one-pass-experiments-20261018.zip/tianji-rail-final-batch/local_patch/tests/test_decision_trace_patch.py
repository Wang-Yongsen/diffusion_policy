"""Hardware-free regression tests for the isolated telemetry patch.

Only the reviewed decision_trace.py is imported by path. No project modules,
drivers, cameras, runtime_files(), or policy models are imported or constructed.
"""
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from types import SimpleNamespace as NS

import numpy as np

SOURCE=Path(__file__).resolve().parents[1]/'source/diffusion_policy/real_world/decision_trace.py'
spec=importlib.util.spec_from_file_location('isolated_decision_trace_under_test',SOURCE)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def trace(**overrides):
    kwargs=dict(decision_capacity=2,feedback_capacity=4,command_capacity=8,hand_capacity=4,status_capacity=2)
    kwargs.update(overrides)
    return module.SessionTrace(**kwargs)

def obs(value=1):
    out={k:np.full((2,2,3,3),value,dtype=np.uint8) for k in module.CAMERAS}
    out.update(robot_eef_pose=np.full((2,12),value,dtype=np.float32),
               hand_joint=np.full((2,40),value,dtype=np.float32))
    return out

def store(t,value=1,**kwargs):
    args=dict(obs=obs(value),alignment={'test':value},anchor_ns=100,actions=np.full((2,52),value),
              started_ns=80,observed_ns=90,preprocessed_ns=95,inputs_ready_ns=96,returned_ns=120)
    args.update(kwargs)
    return t.store_decision(**args)

def event(kind,stamp=1,**details):
    return NS(kind=kind,observed_monotonic_ns=stamp,details=details)

def receipt(command='cmd',device='tianji',status='accepted',stamp=10):
    return NS(command_id=command,device_id=device,status=NS(value=status),observed_monotonic_ns=stamp)

def snap(packet=1):
    arm={'present':True,'source_sequence':packet,'input_sequence':packet,
         'q':np.full(7,float(packet)),'controller_target':np.full(7,float(packet)+.1)}
    return {'present':True,'packet_index':packet,'received_monotonic_ns':packet*10,'ref_sequence':packet,
            'arms':{'left':dict(arm),'right':dict(arm)}}

def hand_sample(value=1):
    return NS(header=NS(received_monotonic_ns=value*10,source_sequence=value,
                        ref=NS(stream='wuji_left_hand/joints')),
              payload=NS(position_rad=[float(value)]*20,joint_names=list(range(20))))

class TestTelemetryPatch(unittest.TestCase):
    def test_ten_thousand_source_gaps_do_not_consume_critical_capacity(self):
        t=trace(status_capacity=2)
        for i in range(10000):t.record_status(event('tianji.source_gap',i,missing=2))
        t.record_status(event('motor.fault',10001,error=7))
        t.record_status(event('watchdog.expired',10002))
        self.assertTrue(t.valid)
        self.assertEqual(t.dropped['status'],0)
        self.assertEqual([x['kind'] for x in t._status],['motor.fault','watchdog.expired'])
        s=t.status_summary['tianji.source_gap']
        self.assertEqual((s['count'],s['first_ns'],s['last_ns']),(10000,0,9999))

    def test_critical_overflow_invalidates_and_retains_existing_events(self):
        t=trace(status_capacity=2)
        for i in range(3):t.record_status(event('fault_'+str(i),i))
        self.assertFalse(t.valid)
        self.assertEqual(t.invalid_reason,'status buffer full')
        self.assertEqual(t.dropped['status'],1)
        self.assertEqual([x['kind'] for x in t._status],['fault_0','fault_1'])

    def test_begin_trial_clears_prelude_counts_and_validity(self):
        t=trace();t.allocate_decisions(obs(),2,capture_real=True)
        t._append_arm(snap());t.append_sample(hand_sample())
        t.record_receipt(receipt());t.record_status(event('tianji.source_gap'))
        store(t,real_obs=obs(2),window_start=50)
        t.mark_invalid('prelude only')
        t.begin_trial()
        self.assertEqual((t.fb_count,t.cmd_count,t.hfb_count,t.decision_count),(0,0,0,0))
        self.assertTrue(t.valid);self.assertIsNone(t.invalid_reason)
        self.assertEqual(t.status_summary,{})
        self.assertEqual(t._cmd_index,{})
        self.assertFalse(t.present.any());self.assertFalse(t.real_present.any())
        self.assertIsNotNone(t.recording_start_ns);self.assertIsNone(t.recording_end_ns)

    def test_hand_receipt_does_not_create_arm_command(self):
        t=trace();t.sink.try_event(receipt(command='hand-1',device='wuji_left_hand'))
        self.assertEqual(t.cmd_count,0)
        t.sink.try_event(receipt(command='arm-1',device='tianji'))
        self.assertEqual(t.cmd_count,1)
        self.assertEqual(t.cmd_id[0],'arm-1')

    def test_new_trial_omitted_window_start_does_not_inherit_prelude(self):
        t=trace();t.allocate_decisions(obs(),2)
        store(t,window_start=50)
        t.begin_trial()
        store(t,2)
        self.assertEqual(t.window_start[0],-1,'new real-input row inherited a prelude demo window index')

    def test_unknown_rejected_and_accepted_are_distinct(self):
        t=trace();executor=NS(tracking_status={},applied_poses={},timing_status={})
        t.record_receipt(receipt('unknown'))
        t.record_submit_result(NS(command_id='rejected'),NS(accepted=False),{},executor)
        t.record_submit_result(NS(command_id='accepted'),NS(accepted=True),{},executor)
        self.assertEqual(t.cmd_accepted[:3].tolist(),[False,False,True])
        self.assertEqual(t.cmd_accepted_present[:3].tolist(),[False,True,True])
        self.assertEqual(t.cmd_device_id[:3].tolist(),['tianji']*3)
        self.assertTrue(t.cmd_sdk_accepted[0])

    def test_live_capture_fields_and_raw_copy_survive_flush(self):
        t=trace();t.allocate_decisions(obs(),2,capture_real=True);t.begin_trial()
        real=obs(7);rng={'cpu':np.arange(5,dtype=np.uint8),'cuda':None,'device':'cpu'}
        store(t,real_obs=real,real_anchor_ns=201,rng=rng,
              live_capture_started_ns=200,live_capture_returned_ns=220)
        real['camera_1'][:]=99;rng['cpu'][:]=99
        with tempfile.TemporaryDirectory() as folder:
            metadata=t.flush(folder)
            disk=json.loads((Path(folder)/'trace_meta.json').read_text())
            self.assertEqual(disk,metadata)
            self.assertTrue(disk['valid']);self.assertEqual(disk['counts']['decisions'],1)
            self.assertEqual(disk['critical_status_dropped'],0)
            self.assertLessEqual(disk['recording_start_ns'],disk['recording_end_ns'])
            self.assertEqual(disk['decisions'][0]['live_capture_started_ns'],200)
            self.assertEqual(disk['decisions'][0]['live_capture_returned_ns'],220)
            with np.load(Path(folder)/'trace_decisions.npz',allow_pickle=False) as a:
                self.assertTrue(a['real_present'][0])
                self.assertTrue((a['real_camera_1'][0]==7).all())
                self.assertEqual(a['real_anchor_ns'][0],201)
                self.assertEqual(a['rng_cpu'][0].tolist(),list(range(5)))
            self.assertEqual(t.decision_count,0)

    def test_decision_overflow_preserves_previous_observation(self):
        t=trace(decision_capacity=1);t.allocate_decisions(obs(),2)
        self.assertEqual(store(t,3),0)
        old=t.images['camera_1'][0].copy();old_action=t.actions[0].copy()
        self.assertIsNone(store(t,9))
        np.testing.assert_array_equal(t.images['camera_1'][0],old)
        np.testing.assert_array_equal(t.actions[0],old_action)
        self.assertFalse(t.valid);self.assertEqual(t.dropped['decisions'],1)

    def test_feedback_overflow_preserves_previous_row(self):
        t=trace(feedback_capacity=1);t._append_arm(snap(1));t._append_arm(snap(2))
        self.assertEqual(t.fb_count,1)
        self.assertEqual(t.fb_packet[0],1)
        np.testing.assert_array_equal(t.fb_q[0,0],np.ones(7))
        self.assertFalse(t.valid);self.assertEqual(t.dropped['feedback'],1)

    def test_status_summary_and_dropped_count_persist_in_metadata(self):
        t=trace(status_capacity=1);t.begin_trial()
        for i in range(100):t.record_status(event('tianji.source_gap',i,missing=i))
        t.record_status(event('fault',200));t.record_status(event('fault',201))
        with tempfile.TemporaryDirectory() as folder:
            m=t.flush(folder)
            self.assertFalse(m['valid']);self.assertEqual(m['critical_status_dropped'],1)
            self.assertEqual(m['dropped']['status'],1)
            self.assertEqual(m['status_summary']['tianji.source_gap']['count'],100)
            self.assertEqual(m['status_summary']['fault']['count'],2)
            self.assertEqual(m['status_summary']['fault']['last_ns'],201)

    def test_frozen_existing_command_cannot_be_mutated_by_receipt(self):
        t=trace();t.record_receipt(receipt('existing',status='queued',stamp=1))
        t._frozen=True
        t.record_receipt(receipt('existing',status='accepted',stamp=2))
        self.assertEqual(t.cmd_receipt[0],'queued')
        self.assertFalse(t.cmd_sdk_accepted[0])

    def test_begin_trial_serializes_pending_feedback_commit(self):
        self._pending_feedback_transition('begin')

    def test_flush_serializes_pending_feedback_commit(self):
        self._pending_feedback_transition('flush')

    def _pending_feedback_transition(self,transition):
        t=trace();entered=threading.Event();release=threading.Event()
        transition_started=threading.Event();transition_finished=threading.Event();errors=[]
        class PausedSnapshot(dict):
            def get(self,key,*args):
                if key=='present':
                    entered.set()
                    if not release.wait(2):raise RuntimeError('test timed out waiting for release')
                return super().get(key,*args)
        def writer():
            try:t._append_arm(PausedSnapshot(snap(1)))
            except BaseException as e:errors.append(e)
        with tempfile.TemporaryDirectory() as folder:
            def boundary():
                transition_started.set()
                try:
                    if transition=='begin':
                        t.begin_trial();t._append_arm(snap(2))
                    else:t.flush(folder)
                except BaseException as e:errors.append(e)
                finally:transition_finished.set()
            w=threading.Thread(target=writer);w.start()
            self.assertTrue(entered.wait(1),'writer never reached reserved-row boundary')
            b=threading.Thread(target=boundary);b.start()
            self.assertTrue(transition_started.wait(1))
            # A correct atomic commit blocks the boundary until release. An
            # unlocked commit lets reset/flush finish before the old row writes.
            transition_finished.wait(.08)
            release.set();w.join(2);b.join(2)
            self.assertFalse(w.is_alive());self.assertFalse(b.is_alive());self.assertEqual(errors,[])
            if transition=='begin':
                self.assertEqual(t.fb_count,1)
                self.assertEqual(t.fb_packet[0],2,'prelude writer overwrote new-trial feedback')
                np.testing.assert_array_equal(t.fb_q[0,0],np.full(7,2.))
            else:
                with np.load(Path(folder)/'trace_feedback.npz',allow_pickle=False) as a:
                    self.assertEqual(a['packet'].tolist(),[1],'flush captured a reserved but uncommitted row')
                    self.assertTrue(a['q_present'][0].all())

if __name__=='__main__':unittest.main(verbosity=2)
