"""Prepare or collect the fixed batch. Never imports robot code or starts hardware.

The generated adapter commands are an integration contract, not a claim that the
current local evaluation entry points already support V/S or unified initialization.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shlex
import zipfile

from inspect_sources import inspect_trace


HERE = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_plan(plan):
    slots = plan["slots"]
    if len(slots) != 13 or len({item["slot_id"] for item in slots}) != 13:
        raise ValueError("The fixed plan must contain 13 unique slots")
    if {item["slot_id"] for item in slots} != {f"P{index:02d}" for index in range(13)}:
        raise ValueError("Only the predeclared P00 through P12 slot names are permitted")
    if slots[0]["kind"] != "demonstration_calibration":
        raise ValueError("The first slot must be calibration")
    counts = Counter(item["condition"] for item in slots[1:])
    if counts != Counter({"C0": 3, "C1": 3, "C2": 3, "C3": 3}):
        raise ValueError("Each of the four closed-loop conditions must occur three times")
    if len({item["initialization_id"] for item in slots}) != 1:
        raise ValueError("Calibration and closed loop must share initialization")
    if plan["limits"]["automatic_hardware_start"]:
        raise ValueError("This controller does not authorize automatic hardware start")
    if plan["limits"]["automatic_replacement_slots"] != 0:
        raise ValueError("Replacement slots are prohibited")
    return plan


def prepare(manifest, destination, project_root):
    plan = validate_plan(read_json(manifest))
    destination.mkdir(parents=True, exist_ok=True)
    copied = destination / "physical_batch.json"
    if copied.exists() and read_json(copied) != plan:
        raise ValueError("Refusing to replace a different prepared batch manifest")
    write_json(copied, plan)
    templates = {
        "visual_candidate.json": {"frozen": False, "candidate_id": None, "formula": None,
                                  "parameters": None, "source_sha256": None,
                                  "note": "Fill from actual offline evidence; no brightness target is assumed."},
        "stability_gate.json": {"frozen": False, "parameters": None,
                                 "max_wait_s": plan["limits"]["max_stability_wait_s"],
                                 "window_s": plan["limits"]["stability_window_s"],
                                 "max_resamples": plan["limits"]["max_resamples_per_decision"]},
        "initialization.json": {"frozen": False, "id": plan["slots"][0]["initialization_id"],
                                "same_function_for_all_slots": True, "calibration_only_bridge": False,
                                "target": None, "measured_thresholds": None, "source_sha256": None},
        "runtime_expected.json": {"frozen": False, "files": {},
                                   "note": "Freeze installed runtime after local_patch and V/S adapter integration. Each files entry must have sha256 and snapshot_path relative to the batch root."},
        "integration_status.json": {"frozen": False, "local_adapter_implemented": False,
                                    "offline_fake_preflight_passed": False,
                                    "hardware_executed_by_this_controller": False,
                                    "required_adapter": plan["local_adapter_contract"]},
    }
    for name, value in templates.items():
        path = destination / name
        if not path.exists():
            write_json(path, value)
    limit = plan["limits"]
    lines = ["# 固定批次本机执行单", "", "此文件由只读控制器生成；服务器没有执行硬件。",
             "现有 CLI 尚未完整实现 V/S 与统一初始化。由本地 AI 一次完成 adapter 集成、离线预检、整批执行和打包；不要每段回来聊天。",
             "先应用同批 local_patch 的哈希保护补丁，再冻结五份配置。不要沿用回放独有的首动作慢速接近。",
             f"总量 13 段；每段 active 最多 {limit['active_duration_s']} 秒 / {limit['max_decisions']} 次决策；无效段仍占 slot，不自动补跑。",
             "", "| 顺序 | 条件 | 重复 | seed | 输入 |", "|---|---|---:|---:|---|"]
    for item in plan["slots"]:
        lines.append(f"| {item['slot_id']} | {item['condition']} | {item['repeat']} | {item['seed']} | {item['control_input']} |")
    lines += ["", "commands.sh 默认 offline-preflight，不启动机器人。仅在本机 adapter 已按本清单实现并通过 fake 检查后，沿用现场人工开始流程执行固定 13 段。",
              "每段保存 slot.json（与清单一致的 ID/条件/seed/初始化与 V/S 哈希、起止时间、人工介入、终态）及完整 trace。",
              "全部 13 个 slot 结束后，执行 controller collect 一次质检并生成一个 ZIP。有效失败不重跑；无效比较须如实进入总报告。",
              "13 段后没有唯一归因时报告不可辨识边界，不自动扩展场景或训练。"]
    (destination / "run_sheet.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    commands = ["#!/usr/bin/env bash", "set -euo pipefail",
                "# Integration contract. Defaults to offline checks; no existing CLI compatibility is claimed.",
                f"BATCH_PROJECT_ROOT=${{BATCH_PROJECT_ROOT:-{shlex.quote(str(project_root))}}}",
                f"BATCH_RESULTS_ROOT=${{BATCH_RESULTS_ROOT:-{shlex.quote(str(destination.resolve()))}}}",
                'BATCH_MODE=${BATCH_MODE:-offline-preflight}',
                'BATCH_ADAPTER="$BATCH_PROJECT_ROOT/scripts/run_tianji_final_batch_slot.py"',
                'test -f "$BATCH_ADAPTER" || { echo "Local AI must implement the documented V/S batch adapter first." >&2; exit 2; }',
                'cd "$BATCH_PROJECT_ROOT"']
    for item in plan["slots"]:
        commands.append('python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" '
                        f'--slot {shlex.quote(item["slot_id"])} --mode "$BATCH_MODE" '
                        '--require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/' + item["slot_id"] + '"')
    (destination / "commands.sh").write_text("\n".join(commands) + "\n", encoding="utf-8")
    return {"prepared": str(destination), "hardware_started": False, "integration_required": True,
            "slots": len(plan["slots"]), "default_mode": "offline-preflight"}


def expected_hashes(value):
    return {name: entry if isinstance(entry, str) else entry["sha256"]
            for name, entry in value.get("files", {}).items()}


def audit_slot(root, item, plan, required, frozen_hashes, runtime_hashes):
    folder = root / item["slot_id"]
    if not folder.resolve().is_relative_to(root.resolve()):
        raise ValueError("Slot directory points outside the result root")
    missing = [name for name in required["per_slot"] if not (folder / name).is_file()]
    issues = ["missing artifact: " + name for name in missing]
    metadata = read_json(folder / "slot.json") if (folder / "slot.json").is_file() else {}
    for name in required["slot_json_required"]:
        if name not in metadata:
            issues.append("slot.json missing field: " + name)
    for name in ("slot_id", "condition", "repeat", "seed"):
        if metadata.get(name) != item[name]:
            issues.append("slot metadata disagrees with plan: " + name)
    for name, value in (("visual_enabled", bool(item.get("visual_candidate", False))),
                        ("stable_sampling_enabled", bool(item.get("stable_sampling", False)))):
        if metadata.get(name) is not value:
            issues.append("actual V/S switch missing or disagrees with plan: " + name)
    terminal = metadata.get("outcome") in required["terminal_outcomes"]
    if not terminal:
        issues.append("slot has no declared terminal outcome")
    if metadata.get("outcome") == "invalid_comparison":
        issues.append("slot is declared invalid for comparison")
    if metadata.get("checkpoint_sha256") != plan["checkpoint_sha256"]:
        issues.append("checkpoint hash mismatch")
    if metadata.get("manual_intervention") is not False:
        issues.append("manual intervention is present or unspecified")
    if metadata.get("initial_state_comparable") is not True:
        issues.append("initial state comparability did not pass")
    for name, field in [("initialization.json", "initialization_sha256"),
                        ("visual_candidate.json", "visual_candidate_sha256"),
                        ("stability_gate.json", "stability_gate_sha256")]:
        if frozen_hashes.get(name) is None or metadata.get(field) != frozen_hashes[name]:
            issues.append("frozen configuration hash missing/mismatch: " + name)
    start, finish = metadata.get("active_started_ns"), metadata.get("active_finished_ns")
    if isinstance(start, int) and isinstance(finish, int) and finish >= start:
        # Timeout signalling may be followed by bounded stop/drain. Record that delay separately.
        elapsed = (finish - start) / 1e9
        if elapsed > plan["limits"]["active_duration_s"] + 0.5:
            issues.append("active duration exceeds hard limit plus stop/drain tolerance")
    else:
        issues.append("active time is missing or invalid")
    prov_path = folder / "source_provenance.json"
    if prov_path.is_file():
        actual = expected_hashes(read_json(prov_path))
        if not runtime_hashes:
            issues.append("no frozen runtime source hashes")
        for name, digest in runtime_hashes.items():
            if actual.get(name) != digest:
                issues.append("runtime source hash missing/mismatch: " + name)
    trace = None
    trace_path = folder / "trial_0001/trace_meta.json"
    if trace_path.is_file():
        trace = inspect_trace(trace_path)
        issues.extend(trace["limitations"])
        if trace.get("counts", {}).get("decisions", 0) > plan["limits"]["max_decisions"]:
            issues.append("decision count exceeds declared cap")
        if item["condition"] == "REF" and not trace.get("capture_real"):
            issues.append("calibration does not contain simultaneous real observations")
        if trace.get("bridge_chunks_without_prediction_id", 0):
            issues.append("unmatched bridge chunks exist; common initialization/control boundary needs audit")
    return {"slot_id": item["slot_id"], "condition": item["condition"], "terminal": terminal,
            "declared_outcome": metadata.get("outcome"), "artifact_files_present": not missing,
            "comparison_usable": not issues, "issues": sorted(set(issues)), "trace": trace}


def collect(root, archive=None):
    plan = validate_plan(read_json(root / "physical_batch.json"))
    required = read_json(HERE / "required_artifacts.json")
    freeze_files = ("visual_candidate.json", "stability_gate.json", "initialization.json",
                    "runtime_expected.json", "integration_status.json")
    missing = [name for name in required["batch_root_files"] if not (root / name).is_file()]
    issues = ["batch root missing: " + name for name in missing]
    frozen_hashes = {}
    for name in freeze_files:
        path = root / name
        if path.is_file():
            frozen_hashes[name] = sha256(path)
            if read_json(path).get("frozen") is not True:
                issues.append("configuration not frozen: " + name)
    integration = read_json(root / "integration_status.json") if (root / "integration_status.json").is_file() else {}
    for name in ("local_adapter_implemented", "offline_fake_preflight_passed"):
        if integration.get(name) is not True:
            issues.append("local integration prerequisite missing: " + name)
    runtime = read_json(root / "runtime_expected.json") if (root / "runtime_expected.json").is_file() else {}
    hashes = expected_hashes(runtime)
    for name, entry in runtime.get("files", {}).items():
        relative = entry.get("snapshot_path") if isinstance(entry, dict) else None
        if not relative:
            issues.append("runtime source snapshot missing: " + name)
            continue
        snapshot = (root / relative).resolve()
        if not snapshot.is_relative_to(root.resolve()) or not snapshot.is_file():
            issues.append("runtime source snapshot absent or outside batch: " + name)
        elif sha256(snapshot) != hashes[name]:
            issues.append("runtime source snapshot hash mismatch: " + name)
    slots = []
    for item in plan["slots"]:
        try:
            slots.append(audit_slot(root, item, plan, required, frozen_hashes, hashes))
        except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
            metadata_path = root / item["slot_id"] / "slot.json"
            try:
                metadata = read_json(metadata_path)
            except (OSError, ValueError):
                metadata = {}
            slots.append({"slot_id": item["slot_id"], "condition": item["condition"],
                          "terminal": metadata.get("outcome") in required["terminal_outcomes"],
                          "comparison_usable": False, "issues": ["artifact parse error: " + str(error)]})
    complete = all(item["terminal"] for item in slots)
    report = {"hardware_started_by_controller": False, "expected_slots": 13,
              "terminal_slots": sum(item["terminal"] for item in slots),
              "all_slots_terminal": complete, "batch_issues": issues, "slots": slots,
              "all_comparisons_usable": not issues and all(item["comparison_usable"] for item in slots),
              "automatic_replacement_slots": 0,
              "interpretation": "Invalid or failed slots remain part of this fixed batch. No extra trials are requested automatically."}
    write_json(root / "batch_qc.json", report)
    if archive is not None:
        if not complete:
            report["archive_not_created"] = "Not all 13 slots have terminal records; finish the planned batch once, without adding slots."
            write_json(root / "batch_qc.json", report)
            return report
        if archive.exists():
            raise FileExistsError("Refusing to overwrite an existing result archive")
        archive.parent.mkdir(parents=True, exist_ok=True)
        files = [path for path in sorted(root.rglob("*")) if path.is_file() and path.resolve() != archive.resolve()
                 and path.name != "artifact_manifest.json"]
        if any(path.is_symlink() or not path.resolve().is_relative_to(root.resolve()) for path in files):
            raise ValueError("Refusing to archive symlinks or files outside the batch result root")
        write_json(root / "artifact_manifest.json", {"files": [{"path": str(path.relative_to(root)),
                    "sha256": sha256(path), "bytes": path.stat().st_size} for path in files]})
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as output:
            for path in [*files, root / "artifact_manifest.json"]:
                output.write(path, str(Path(root.name) / path.relative_to(root)))
        report["archive"] = str(archive)
        report["archive_sha256"] = sha256(archive)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=("prepare", "collect"), default="prepare")
    parser.add_argument("--manifest", type=Path, default=HERE / "physical_batch.json")
    parser.add_argument("--batch-root", type=Path, default=HERE.parent / "prepared_local_batch")
    parser.add_argument("--project-root", type=Path, default=Path("/home/yuchen/project/diffusion_policy"))
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        report = prepare(args.manifest, args.batch_root, args.project_root)
    else:
        report = collect(args.batch_root, args.archive)
    if args.command == "collect":
        summary = {key: report.get(key) for key in
                   ("expected_slots", "terminal_slots", "all_slots_terminal", "all_comparisons_usable",
                    "archive", "archive_sha256", "archive_not_created") if report.get(key) is not None}
        summary["qc_report"] = str(args.batch_root / "batch_qc.json")
        summary["usable_slot_count"] = sum(bool(item["comparison_usable"]) for item in report["slots"])
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
