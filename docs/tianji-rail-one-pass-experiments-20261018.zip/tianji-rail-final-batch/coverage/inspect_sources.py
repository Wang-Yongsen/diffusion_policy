"""Read-only classification of supplied experiment folders. Standard library only."""
from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
import struct
import zipfile


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def npz_info(path):
    result = {}
    with zipfile.ZipFile(path) as archive:
        for member in archive.namelist():
            if not member.endswith(".npy"):
                continue
            with archive.open(member) as stream:
                magic = stream.read(8)
                if magic[:6] != b"\x93NUMPY":
                    raise ValueError(f"Invalid NPY magic: {path}:{member}")
                width = 2 if magic[6] == 1 else 4
                length_bytes = stream.read(width)
                length = int.from_bytes(length_bytes, "little")
                if length > 65536:
                    raise ValueError("Oversized NPY header")
                header = ast.literal_eval(stream.read(length).decode("latin1"))
                item = {"shape": list(header["shape"]), "dtype": header["descr"]}
                if member in {"present.npy", "real_present.npy"} and header["descr"] == "|b1":
                    mask = stream.read()
                    item["true_rows"] = sum(bool(value) for value in mask)
                result[member[:-4]] = item
    return result


def inspect_trace(meta_path):
    trial = meta_path.parent
    meta = read_json(meta_path)
    trial_meta = read_json(trial / "trial.json") if (trial / "trial.json").is_file() else {}
    npz = trial / "trace_decisions.npz"
    info = npz_info(npz) if npz.is_file() else {}
    expected = set(("camera_0", "camera_1", "camera_2", "robot_eef_pose", "hand_joint",
                    "actions", "anchor_ns", "started_ns", "returned_ns", "rng_cpu", "rng_cuda"))
    missing = sorted(expected - set(info))
    dropped = meta.get("dropped", {})
    limitations = []
    if not meta.get("valid", False):
        limitations.append("trace marked invalid: " + str(meta.get("invalid_reason")))
    if any(dropped.values()):
        limitations.append("dropped entries: " + json.dumps(dropped, sort_keys=True))
    if missing:
        limitations.append("missing decision fields: " + ", ".join(missing))
    if meta.get("capture_real"):
        real_fields = {"real_" + name for name in ("camera_0", "camera_1", "camera_2", "robot_eef_pose", "hand_joint")}
        absent = sorted(real_fields - set(info))
        if absent:
            limitations.append("paired live fields missing: " + ", ".join(absent))
        count = meta.get("counts", {}).get("decisions", 0)
        if info.get("real_present", {}).get("true_rows", 0) != count:
            limitations.append("not every saved demonstration decision has a live pair")
    status = meta.get("status", [])
    stamps = [event.get("observed_monotonic_ns") for event in status
              if isinstance(event.get("observed_monotonic_ns"), int)]
    started = trial_meta.get("started_monotonic_ns")
    last_before_start = bool(dropped.get("status", 0) and stamps and started is not None and max(stamps) < started)
    if last_before_start:
        limitations.append("status buffer exhausted before trial; movement-time device events are unauditable")
    events = trial / "events.jsonl"
    decisions = 0
    scheduled = 0
    dropped_steps = 0
    bridge_chunks = 0
    if events.is_file():
        for line in events.read_text().splitlines():
            event = json.loads(line)
            if event.get("event") in {"prediction", "recorded_window"}:
                decisions += 1
            if event.get("event") == "schedule":
                scheduled += 1
                dropped_steps += event.get("dropped_steps", 0)
                bridge_chunks += event.get("prediction_id") is None
    saved = meta.get("counts", {}).get("decisions", 0)
    if decisions > saved:
        limitations.append(f"{decisions - saved} executed/predicted decisions lack saved full input")
    return {"source_type": "motion_trace", "path": str(trial.resolve()),
            "trace_valid": meta.get("valid"), "dropped": dropped, "counts": meta.get("counts"),
            "capture_real": meta.get("capture_real"), "decision_fields": info,
            "events_decisions": decisions, "scheduled_chunks": scheduled,
            "bridge_chunks_without_prediction_id": bridge_chunks, "retime_dropped_steps": dropped_steps,
            "status_exhausted_before_trial": last_before_start,
            "supports": ["saved early input/output sensitivity", "numeric command/feedback layers"],
            "limitations": limitations,
            "full_chain_comparison_usable": bool(meta.get("valid")) and not limitations}


def inspect_root(root):
    root = root.resolve()
    result = []
    trace_paths = list(root.rglob("trace_meta.json"))
    trace_trials = {path.parent for path in trace_paths}
    for path in sorted(trace_paths):
        result.append(inspect_trace(path))
    for raw in sorted(root.rglob("raw_observation.npz")):
        folder = raw.parent
        metadata = read_json(folder / "metadata.json") if (folder / "metadata.json").is_file() else {}
        result.append({"source_type": "snapshot", "path": str(folder), "mode": metadata.get("mode"),
                       "checkpoint_sha256": metadata.get("checkpoint_sha256"), "fields": npz_info(raw),
                       "supports": ["same snapshot replay", "paired field intervention if a reference is present"],
                       "limitations": ["one snapshot is not a historical failure window or motion trajectory"],
                       "full_chain_comparison_usable": False})
    for trial_meta in sorted(root.rglob("trial.json")):
        folder = trial_meta.parent
        if folder in trace_trials:
            continue
        result.append({"source_type": "legacy_motion", "path": str(folder),
                       "sparse_windows": len(list(folder.glob("obs*.npz"))),
                       "supports": ["scheduled targets and whatever measured fields are explicitly present"],
                       "limitations": ["full input/RNG/status coverage must not be inferred from sparse windows"],
                       "full_chain_comparison_usable": False})
    return {"root": str(root), "sources": result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("roots", type=Path, nargs="+")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = {"read_only": True, "source_packages_executed": False,
              "source_counts_are_artifact_directories_not_independent_samples": True,
              "reports": [inspect_root(root) for root in args.roots]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
