"""Contract tests for this offline preparation/collection tool; no robot imports."""
import json
from pathlib import Path
import tempfile
import unittest

from batch_controller import HERE, collect, prepare, read_json, validate_plan


class BatchControllerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "results"
        self.manifest = HERE / "physical_batch.json"

    def test_default_preparation_is_explicitly_offline_and_preserves_frozen_files(self):
        result = prepare(self.manifest, self.root, Path("/local/project"))
        self.assertFalse(result["hardware_started"])
        self.assertTrue(result["integration_required"])
        commands = (self.root / "commands.sh").read_text()
        self.assertIn("offline-preflight", commands)
        self.assertNotIn("--motion", commands)
        self.assertEqual(commands.count("--require-manual-start --no-auto-retry"), 13)
        custom = {"frozen": True, "candidate_id": "preserve_me"}
        (self.root / "visual_candidate.json").write_text(json.dumps(custom))
        prepare(self.manifest, self.root, Path("/local/project"))
        self.assertEqual(read_json(self.root / "visual_candidate.json"), custom)

    def test_missing_slots_never_produce_an_archive_or_hidden_retries(self):
        prepare(self.manifest, self.root, Path("/local/project"))
        archive = self.root.parent / "result.zip"
        report = collect(self.root, archive)
        self.assertFalse(report["all_slots_terminal"])
        self.assertFalse(archive.exists())
        self.assertEqual(len(report["slots"]), 13)
        self.assertEqual(report["automatic_replacement_slots"], 0)

    def test_thirteen_terminal_invalid_slots_are_packaged_with_issues_not_replaced(self):
        prepare(self.manifest, self.root, Path("/local/project"))
        for item in read_json(self.manifest)["slots"]:
            folder = self.root / item["slot_id"]
            folder.mkdir()
            (folder / "slot.json").write_text(json.dumps({**item, "outcome": "invalid_comparison"}))
        archive = self.root.parent / "all_evidence.zip"
        report = collect(self.root, archive)
        self.assertTrue(report["all_slots_terminal"])
        self.assertFalse(report["all_comparisons_usable"])
        self.assertTrue(archive.exists())
        self.assertEqual(report["terminal_slots"], 13)
        self.assertEqual(len(list(self.root.glob("P*"))), 13)

    def test_plan_rejects_extra_slots_or_different_initialization(self):
        plan = read_json(self.manifest)
        plan["slots"].append(plan["slots"][-1])
        with self.assertRaises(ValueError):
            validate_plan(plan)
        plan = read_json(self.manifest)
        plan["slots"][0]["initialization_id"] = "replay_only_bridge"
        with self.assertRaises(ValueError):
            validate_plan(plan)


if __name__ == "__main__":
    unittest.main()
