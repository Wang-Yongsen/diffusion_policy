"""Finite offline input diagnostic matrix; no hardware or uploaded code execution.

Sources are saved observations only. Model/preprocessor are trusted server APIs.
Image encoding is cached only after full predict_action equivalence checks.
"""
from pathlib import Path
import csv
import hashlib
import itertools
import json
import sys
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

PROJECT=Path('/home/jiyuchen/project/WYS/diffusion_policy')
CHAT=Path('/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1')
INPUT=CHAT/'received_decision_trace_20261018/tianji-rail-decision-trace-20261018/motion'
OUT=Path(__file__).parent
CKPT=PROJECT/'data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt'
sys.path.insert(0,str(PROJECT))
from eval_tianji_rail import load_policy
from diffusion_policy.real_world.tianji_rail_env import preprocess_observation

KEYS=('camera_0','camera_1','camera_2','robot_eef_pose','hand_joint')
SEEDS=(42,43,44)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def load_saved(name):
    path=INPUT/name/'trial_0001/trace_decisions.npz'
    with np.load(path,allow_pickle=False) as z:
        present=z['present'].copy()
        d={k:np.array(z[k],copy=True) for k in KEYS}
        result={'D':d,'logged_actions':z['actions'].copy(),'present':present,
                'anchor_ns':z['anchor_ns'].copy(),'returned_ns':z['returned_ns'].copy()}
        if name=='replay':
            assert np.all(z['real_present'])
            result['R']={k:np.array(z['real_'+k],copy=True) for k in KEYS}
        else:result['R']=d
    return result

raw={'replay':load_saved('replay'),'closed':load_saved('closed')}
assert len(raw['replay']['present'])==24 and raw['replay']['present'].all()
assert len(raw['closed']['present'])==48 and raw['closed']['present'].all()
torch.set_num_threads(2)
policy,cfg,model_key=load_policy(CKPT,'cpu')
assert policy.obs_as_cond and not policy.pred_action_steps_only
assert policy.n_obs_steps==2 and policy.horizon==16 and policy.n_action_steps==8
assert policy.num_inference_steps==8
encoder=policy.obs_encoder
print('Loaded epoch50',model_key,'CPU2',flush=True)

# Every descriptor maps each observation field to (D/R, history: native/old/new).
def spec(camera='DDD',state='D',cam1_history='native',state_history='native',eef=None,hand=None):
    out={k:(camera[j],'native') for j,k in enumerate(KEYS[:3])}
    out['camera_1']=(camera[1],cam1_history)
    out['robot_eef_pose']=(state if eef is None else eef,state_history)
    out['hand_joint']=(state if hand is None else hand,state_history)
    return out

cases=[]
seen={}
def add(run,index,label,descriptor,tags=()):
    signature=(run,index,tuple((k,*descriptor[k]) for k in KEYS))
    if signature in seen:
        seen[signature]['aliases'].append(label)
        seen[signature]['tags'].extend(t for t in tags if t not in seen[signature]['tags'])
        return
    item={'run':run,'decision':index,'condition':label,'aliases':[label],
          'tags':list(tags),'spec':descriptor}
    cases.append(item);seen[signature]=item

for i in range(8):
    for cameras in itertools.product('DR',repeat=3):
        for state in 'DR':
            c=''.join(cameras)
            add('replay',i,f'{c}_{state}',spec(c,state),('factorial',))

core=[('EE',spec()),('RR',spec('RRR','R')),
      ('real_cam1_demo_base',spec('DRD','D')),
      ('demo_cam1_real_base',spec('RDR','R')),
      ('real_images_demo_state',spec('RRR','D')),
      ('demo_images_real_state',spec('DDD','R')),
      ('real_eef_demo_base',spec(eef='R')),
      ('real_hand_demo_base',spec(hand='R')),
      ('RR_cam1_repeat_old',spec('RRR','R',cam1_history='old')),
      ('RR_cam1_repeat_new',spec('RRR','R',cam1_history='new')),
      ('RR_state_repeat_old',spec('RRR','R',state_history='old')),
      ('RR_state_repeat_new',spec('RRR','R',state_history='new'))]
for i in range(24):
    for label,descriptor in core:add('replay',i,label,descriptor,('all_replay',))
for i in range(48):
    for label,descriptor in (core[1],*core[8:]):add('closed',i,label,descriptor,('closed_history',))
assert len(cases)==608, len(cases)

features={}
feature_fields=tuple(encoder.obs_shapes)
assert set(feature_fields)==set(KEYS)

def build_features(run,index,source):
    key=(run,index,source)
    if key in features:return features[key]
    obs={k:raw[run][source][k][index] for k in KEYS}
    prepared=preprocess_observation(obs,cfg.task.shape_meta,cfg.task.dataset)
    tensors={k:torch.from_numpy(v).unsqueeze(0) for k,v in prepared.items()}
    normalized=policy.normalizer.normalize(tensors)
    per_field={}
    with torch.inference_mode():
        for k in feature_fields:
            x=normalized[k].reshape(-1,*normalized[k].shape[2:])
            randomizer=encoder.obs_randomizers[k]
            if randomizer is not None:x=randomizer.forward_in(x)
            if encoder.obs_nets[k] is not None:
                x=encoder.obs_nets[k](x)
                if encoder.activation is not None:x=encoder.activation(x)
            if randomizer is not None:x=randomizer.forward_out(x)
            per_field[k]=x.flatten(start_dim=1).clone()
    features[key]=per_field
    return per_field

def from_history(x,history):
    if history=='native':return x
    j=0 if history=='old' else 1
    return x[[j,j]]

def encode(case):
    parts=[]
    for k in feature_fields:
        source,hist=case['spec'][k]
        x=build_features(case['run'],case['decision'],source)[k]
        parts.append(from_history(x,hist))
    return torch.cat(parts,dim=-1).reshape(1,policy.n_obs_steps,-1)

def materialize(case):
    return {k:from_history(raw[case['run']][source][k][case['decision']],hist).copy()
            for k,(source,hist) in case['spec'].items()}

def set_seed(seed):
    torch.manual_seed(seed);np.random.seed(seed)
    policy.reset()

def cached_predict(case,seed):
    cond=encode(case)
    set_seed(seed)
    with torch.inference_mode():
        zeros=torch.zeros((1,policy.horizon,policy.action_dim),dtype=policy.dtype,device=policy.device)
        sampled=policy.conditional_sample(zeros,torch.zeros_like(zeros,dtype=torch.bool),cond=cond,**policy.kwargs)
        action=policy.normalizer['action'].unnormalize(sampled[...,:policy.action_dim])
        start=policy.n_obs_steps-1
        return action[0,start:start+policy.n_action_steps].cpu().numpy().copy()

def full_predict(case,seed):
    prepared=preprocess_observation(materialize(case),cfg.task.shape_meta,cfg.task.dataset)
    tensors={k:torch.from_numpy(v).unsqueeze(0) for k,v in prepared.items()}
    set_seed(seed)
    with torch.inference_mode():
        return policy.predict_action(tensors)['action'][0].numpy().copy()

def find(run,index,alias):
    return next(c for c in cases if c['run']==run and c['decision']==index and alias in c['aliases'])

checks=[]
validation=[find('replay',0,'EE'),find('replay',0,'RR'),find('replay',0,'real_cam1_demo_base'),
            find('replay',1,'RR_cam1_repeat_old'),find('replay',1,'RR_cam1_repeat_new'),
            find('replay',7,'RDR_R'),find('closed',0,'RR'),find('closed',10,'RR_state_repeat_old')]
started=time.monotonic()
with threadpool_limits(limits=2):
    for case in validation:
        a=cached_predict(case,42);b=full_predict(case,42)
        gap=float(np.max(np.abs(a-b)))
        checks.append({'run':case['run'],'decision':case['decision'],'condition':case['condition'],
                       'seed':42,'max_abs_52d':gap,'left_xyz_max_abs_mm':float(np.max(np.abs(a[:,:3]-b[:,:3]))*1000)})
        assert gap<=1e-6, checks[-1]
        print('CACHE_VALIDATED',case['run'],case['decision'],case['condition'],gap,flush=True)

    manifest={'source':str(INPUT),'checkpoint':str(CKPT),'checkpoint_sha256':sha(CKPT),
              'model_key':model_key,'device':'cpu','threads':2,'seeds':list(SEEDS),
              'n_unique_inputs':len(cases),'n_predictions':len(cases)*len(SEEDS),
              'cache_validation':checks,'matrix':cases,'feature_field_order':list(feature_fields),
              'limitations':['No physical execution or closed-loop success is tested.',
                'All real/demo camera swaps can create physically inconsistent combinations.',
                'History tests repeat the actual older/newer frame; they do not synthesize another 33 ms of scene evolution.',
                'Closed replay on CPU with a fixed seed is not exact restoration of recorded CUDA noise.',
                'Effects are differences to same-seed policy outputs, not errors to a correct action label.',
                'Low-dimensional sources replace both arms and/or both hands together.',
                'The first eight factorial windows are correlated times from one scene, not eight independent environments.']}
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

    n=len(cases)*len(SEEDS)
    predictions=np.empty((n,8,52),dtype=np.float32)
    case_ids=np.empty(n,dtype=np.int32);seed_ids=np.empty(n,dtype=np.int32)
    position=0;sampled_start=time.monotonic()
    with (OUT/'progress.log').open('w') as progress:
        for case_id,case in enumerate(cases):
            for seed in SEEDS:
                a=cached_predict(case,seed)
                assert a.shape==(8,52) and np.isfinite(a).all()
                predictions[position]=a;case_ids[position]=case_id;seed_ids[position]=seed
                position+=1
            if (case_id+1)%24==0 or case_id+1==len(cases):
                elapsed=time.monotonic()-sampled_start
                eta=elapsed*(len(cases)-case_id-1)/(case_id+1)
                line=f'{case_id+1}/{len(cases)} inputs, {position}/{n} predictions, elapsed={elapsed:.1f}s eta={eta:.1f}s'
                print(line,flush=True);progress.write(line+'\n');progress.flush()
    np.savez_compressed(OUT/'predictions.npz',actions=predictions,case_id=case_ids,seed=seed_ids)
    manifest['elapsed_s']=time.monotonic()-started
    manifest['sampling_elapsed_s']=time.monotonic()-sampled_start
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

lookup={(int(cid),int(seed)):a for cid,seed,a in zip(case_ids,seed_ids,predictions)}
case_index={id(c):i for i,c in enumerate(cases)}
def get(run,index,alias,seed):return lookup[(case_index[id(find(run,index,alias))],seed)]

summary=[]
effects=[]
with (OUT/'predictions.csv').open('w',newline='') as f:
    columns=['run','decision','case_id','condition','aliases','seed','reference',
             'left_target_dx_mean_mm','left_target_dy_mean_mm','left_target_dz_mean_mm',
             'left_target_distance_mean_mm','left_target_distance_max_mm',
             'left_relative_z_last_mm','left_z_last_mm','right_target_distance_mean_mm']
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
    for cid,case in enumerate(cases):
        current=raw[case['run']]['R']['robot_eef_pose'][case['decision'],-1,:3]
        for seed in SEEDS:
            a=lookup[(cid,seed)];base=get(case['run'],case['decision'],'EE' if case['run']=='replay' else 'RR',seed)
            d=(a[:,:3]-base[:,:3])*1000;norm=np.linalg.norm(d,axis=-1)
            row={'run':case['run'],'decision':case['decision'],'case_id':cid,'condition':case['condition'],
                 'aliases':'|'.join(case['aliases']),'seed':seed,'reference':'EE' if case['run']=='replay' else 'RR',
                 'left_target_dx_mean_mm':float(d[:,0].mean()),'left_target_dy_mean_mm':float(d[:,1].mean()),
                 'left_target_dz_mean_mm':float(d[:,2].mean()),'left_target_distance_mean_mm':float(norm.mean()),
                 'left_target_distance_max_mm':float(norm.max()),
                 'left_relative_z_last_mm':float((a[-1,2]-current[2])*1000),'left_z_last_mm':float(a[-1,2]*1000),
                 'right_target_distance_mean_mm':float(np.linalg.norm((a[:,6:9]-base[:,6:9])*1000,axis=-1).mean())}
            writer.writerow(row);summary.append(row)

# Differences use full absolute XYZ trajectories with the same seed and decision.
for run,count in (('replay',24),('closed',48)):
    for index in range(count):
        pairs=[('cam1_repeat_old_vs_native','RR_cam1_repeat_old','RR'),
               ('cam1_repeat_new_vs_native','RR_cam1_repeat_new','RR'),
               ('state_repeat_old_vs_native','RR_state_repeat_old','RR'),
               ('state_repeat_new_vs_native','RR_state_repeat_new','RR')]
        if run=='replay':pairs += [('real_cam1_on_demo','real_cam1_demo_base','EE'),
               ('real_cam1_on_real','RR','demo_cam1_real_base'),
               ('real_images_on_demo_state','real_images_demo_state','EE'),
               ('real_state_on_demo_images','demo_images_real_state','EE'),
               ('real_eef_on_demo','real_eef_demo_base','EE'),('real_hand_on_demo','real_hand_demo_base','EE'),
               ('real_vs_demo','RR','EE')]
        for label,c1,c0 in pairs:
            for seed in SEEDS:
                d=(get(run,index,c1,seed)[:,:3]-get(run,index,c0,seed)[:,:3])*1000
                effects.append({'run':run,'decision':index,'seed':seed,'effect':label,
                    'delta_xyz_mean_mm':d.mean(0).tolist(),'delta_xyz_last_mm':d[-1].tolist(),
                    'distance_mean_mm':float(np.linalg.norm(d,axis=-1).mean()),
                    'distance_max_mm':float(np.linalg.norm(d,axis=-1).max())})

factorial=[]
for index in range(8):
    for state in 'DR':
        for seed in SEEDS:
            action={''.join(c):get('replay',index,''.join(c)+'_'+state,seed)[:,:3]*1000
                    for c in itertools.product('DR',repeat=3)}
            for subset_size in (1,2,3):
                for subset in itertools.combinations(range(3),subset_size):
                    contrasts=[]
                    remainder=[j for j in range(3) if j not in subset]
                    for other in itertools.product('DR',repeat=len(remainder)):
                        d=np.zeros((8,3))
                        for active in itertools.product((0,1),repeat=len(subset)):
                            letters=['D']*3
                            for j,v in zip(remainder,other):letters[j]=v
                            for j,v in zip(subset,active):letters[j]='R' if v else 'D'
                            d += (-1)**(len(subset)-sum(active))*action[''.join(letters)]
                        contrasts.append(d)
                    d=np.mean(contrasts,axis=0)
                    factorial.append({'decision':index,'state':state,'seed':seed,
                        'effect':'x'.join('camera_'+str(j) for j in subset),
                        'order':subset_size,'delta_xyz_mean_mm':d.mean(0).tolist(),
                        'delta_xyz_last_mm':d[-1].tolist(),
                        'distance_mean_mm':float(np.linalg.norm(d,axis=-1).mean())})

(OUT/'effects.json').write_text(json.dumps({'paired_effects':effects,'factorial_contrasts':factorial},ensure_ascii=False,indent=2))
with (OUT/'effects.csv').open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['run','decision','state','seed','effect','order','mean_dx_mm','mean_dy_mm','mean_dz_mm','distance_mean_mm'])
    for r in effects:writer.writerow([r['run'],r['decision'],'',r['seed'],r['effect'],'',*r['delta_xyz_mean_mm'],r['distance_mean_mm']])
    for r in factorial:writer.writerow(['replay_factorial',r['decision'],r['state'],r['seed'],r['effect'],r['order'],*r['delta_xyz_mean_mm'],r['distance_mean_mm']])

aggregates={}
for run in ('replay','closed'):
    for label in sorted({r['effect'] for r in effects if r['run']==run}):
        rows=[r for r in effects if r['run']==run and r['effect']==label]
        aggregates[run+'__'+label]={'n_seed_windows':len(rows),
          'distance_mean_mm':float(np.mean([r['distance_mean_mm'] for r in rows])),
          'distance_max_mm':float(np.max([r['distance_max_mm'] for r in rows])),
          'delta_xyz_mean_mm':np.mean([r['delta_xyz_mean_mm'] for r in rows],axis=0).tolist()}
for state in 'DR':
    for label in sorted({r['effect'] for r in factorial}):
        rows=[r for r in factorial if r['state']==state and r['effect']==label]
        aggregates['factorial_'+state+'__'+label]={'distance_mean_mm':float(np.mean([r['distance_mean_mm'] for r in rows])),
          'distance_max_window_mm':float(np.max([r['distance_mean_mm'] for r in rows])),
          'delta_xyz_mean_mm':np.mean([r['delta_xyz_mean_mm'] for r in rows],axis=0).tolist()}
(OUT/'summary.json').write_text(json.dumps({'aggregates':aggregates,'elapsed_s':manifest['elapsed_s'],
    'n_predictions':n,'cache_validation':checks},ensure_ascii=False,indent=2))
print('FINISHED',n,'predictions',manifest['elapsed_s'],'seconds',OUT,flush=True)
