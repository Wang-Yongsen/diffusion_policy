"""Summarize the fixed matrix without any model or hardware calls."""
from pathlib import Path
import json
import numpy as np

OUT=Path(__file__).parent
m=json.loads((OUT/'manifest.json').read_text());cases=m['matrix']
with np.load(OUT/'predictions.npz',allow_pickle=False) as z:
    actions=z['actions'];case_ids=z['case_id'];seeds=z['seed']
lookup={(int(c),int(s)):a for c,s,a in zip(case_ids,seeds,actions)}
index={}
for cid,c in enumerate(cases):
    for alias in c['aliases']:index[(c['run'],c['decision'],alias)]=cid
def action(run,i,alias,seed):return lookup[(index[(run,i,alias)],seed)]
def statistics(vectors):
    a=np.asarray(vectors,dtype=np.float64)
    norms=np.linalg.norm(a,axis=-1)
    return {'n_seed_windows':int(a.shape[0]),'n_8step_targets':int(norms.size),
            'mean_vector_mm':a.mean((0,1)).tolist(),
            'mean_target_distance_mm':float(norms.mean()),'median_target_distance_mm':float(np.median(norms)),
            'p95_target_distance_mm':float(np.quantile(norms,.95)),
            'max_target_distance_mm':float(norms.max()),
            'mean_endpoint_distance_mm':float(norms[:,-1].mean()),
            'max_abs_mean_y_by_seed_window_mm':float(np.max(np.abs(a[:,:,1].mean(1))))}

result={'meaning':'All distances compare same-seed policy outputs. They are not action correctness errors.',
        'groups':{},'per_decision':{},'factorial_groups':{}}
paired={'cam1_demo_base':('real_cam1_demo_base','EE'),
        'cam1_real_base':('RR','demo_cam1_real_base'),
        'all_images_demo_state':('real_images_demo_state','EE'),
        'all_images_real_state':('RR','demo_images_real_state'),
        'all_state_demo_images':('demo_images_real_state','EE'),
        'all_state_real_images':('RR','real_images_demo_state'),
        'eef_demo_base':('real_eef_demo_base','EE'),
        'hand_demo_base':('real_hand_demo_base','EE'),
        'real_vs_demo':('RR','EE'),
        'cam1_repeat_old':('RR_cam1_repeat_old','RR'),
        'cam1_repeat_new':('RR_cam1_repeat_new','RR'),
        'state_repeat_old':('RR_state_repeat_old','RR'),
        'state_repeat_new':('RR_state_repeat_new','RR')}
for run,n in (('replay',24),('closed',48)):
    for name,(c1,c0) in paired.items():
        if run=='closed' and 'repeat' not in name:continue
        by_decision=[]
        for i in range(n):
            vectors=[(action(run,i,c1,s)[:,:3]-action(run,i,c0,s)[:,:3])*1000 for s in m['seeds']]
            result['per_decision'][f'{run}_{i}_{name}']=statistics(vectors)
            by_decision.extend(vectors)
        result['groups'][run+'_'+name]=statistics(by_decision)

for name,terms in (
    ('image_state_interaction',[(1,'RR'),(-1,'real_images_demo_state'),(-1,'demo_images_real_state'),(1,'EE')]),
    ('eef_hand_interaction',[(1,'demo_images_real_state'),(-1,'real_eef_demo_base'),(-1,'real_hand_demo_base'),(1,'EE')])):
    vectors=[]
    for i in range(24):
        vv=[]
        for s in m['seeds']:
            a=sum(coefficient*action('replay',i,alias,s)[:,:3] for coefficient,alias in terms)*1000
            vectors.append(a);vv.append(a)
        result['per_decision'][f'replay_{i}_{name}']=statistics(vv)
    result['groups']['replay_'+name]=statistics(vectors)

# Average finite-difference effects across contexts, retaining the full 8-step vector.
for state in 'DR':
    for subset in ((0,),(1,),(2,),(0,1),(0,2),(1,2),(0,1,2)):
        vectors=[]
        import itertools
        for i in range(8):
            for seed in m['seeds']:
                contexts=[]
                remainder=[j for j in range(3) if j not in subset]
                for other in itertools.product('DR',repeat=len(remainder)):
                    d=np.zeros((8,3))
                    for active in itertools.product((0,1),repeat=len(subset)):
                        letters=['D']*3
                        for j,v in zip(remainder,other):letters[j]=v
                        for j,v in zip(subset,active):letters[j]='R' if v else 'D'
                        d+=(-1)**(len(subset)-sum(active))*action('replay',i,''.join(letters)+'_'+state,seed)[:,:3]*1000
                    contexts.append(d)
                vectors.append(np.mean(contexts,axis=0))
        result['factorial_groups'][state+'_'+'x'.join('cam'+str(j) for j in subset)]=statistics(vectors)

(OUT/'detailed_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for key,value in result['groups'].items():print(key,round(value['mean_target_distance_mm'],3),'p95',round(value['p95_target_distance_mm'],3),'max',round(value['max_target_distance_mm'],3))
for key,value in result['factorial_groups'].items():print('factorial',key,round(value['mean_target_distance_mm'],3),'max',round(value['max_target_distance_mm'],3))
