#!/usr/bin/env bash
set -euo pipefail
# Integration contract. Defaults to offline checks; no existing CLI compatibility is claimed.
BATCH_PROJECT_ROOT=${BATCH_PROJECT_ROOT:-/home/yuchen/project/diffusion_policy}
BATCH_RESULTS_ROOT=${BATCH_RESULTS_ROOT:-/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1/artifacts/final_batch_20261018/prepared_local_batch}
BATCH_MODE=${BATCH_MODE:-offline-preflight}
BATCH_ADAPTER="$BATCH_PROJECT_ROOT/scripts/run_tianji_final_batch_slot.py"
test -f "$BATCH_ADAPTER" || { echo "Local AI must implement the documented V/S batch adapter first." >&2; exit 2; }
cd "$BATCH_PROJECT_ROOT"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P00 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P00"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P01 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P01"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P02 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P02"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P03 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P03"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P04 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P04"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P05 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P05"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P06 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P06"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P07 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P07"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P08 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P08"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P09 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P09"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P10 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P10"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P11 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P11"
python "$BATCH_ADAPTER" --manifest "$BATCH_RESULTS_ROOT/physical_batch.json" --slot P12 --mode "$BATCH_MODE" --require-manual-start --no-auto-retry --output "$BATCH_RESULTS_ROOT/P12"
