导轨问题一次性实验交接包 2026-10-18

当前已完成：1824条离线预测、全部24回放/48闭环窗口分析、记录与源码审计。
尚未执行：固定13段真机对照。服务器没有本机机器人执行通道。

本地AI请以PLAN.md为唯一后续入口，一次完成本机适配、预检、P00至P12和整批分析，不要逐段传回或让用户逐项追问。13段是1校准+V/S四格各3重复，单段10秒或24决策先到即止。不能把未运行说成已完成；不能自动加替代段。

local_patch包含记录修复源码、哈希保护安装器及测试。安装器默认只读检查；本机文件不同则合并，不能覆盖。V/S及统一初始化adapter没有伪称已实现，它和静态参数冻结由本地AI在同一次准备中完成，先无硬件预检再沿现有人工开始流程运行。

offline_inputs：1824条52维动作、CSV、完整性与敏感性/交互统计。
motion_audit：全量运动与相机时间审计、批次trace标准及QC。
coverage：13段manifest、一次准备/收集打包工具、证据覆盖、可执行位置核查。
prepared_local_batch：尚未冻结的本机集成模板及执行单。

本地准备命令（不会启动硬件）：
python coverage/batch_controller.py prepare --project-root /home/yuchen/project/diffusion_policy --batch-root ./prepared_local_batch

整个现场批次完成后的单次检查/打包：
python coverage/batch_controller.py collect --batch-root ./prepared_local_batch --archive ./tianji-rail-final-batch-results.zip

collect要求本机V/S、初始化、实际源码快照与参数已冻结，以及13个slot终态。当前模板故意是未冻结状态，不能仅改true绕过实际集成或检查。
