"""Independent read-only numerical audit. No uploaded module is imported; no transport is opened."""
from pathlib import Path
import csv,hashlib,json,sys
import numpy as np
from scipy.spatial.transform import Rotation
sys.path.insert(0,'/home/jiyuchen/project/WYS/diffusion_policy')
from diffusion_policy.third_party.bimanual_teleop.devices.tianji.model import TianjiKinematics

ROOT=Path('/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1')
DATA=ROOT/'received_decision_trace_20261018/tianji-rail-decision-trace-20261018'
SRC=ROOT/'received_decision_trace_sources_20261018/tianji-rail-decision-trace-sources-20261018/source'
OUT=ROOT/'artifacts/final_batch_20261018/motion_audit'
SIDES=('left','right');CAMS=('camera_0','camera_1','camera_2')

def stat(values):
 a=np.asarray(values,dtype=float).ravel();a=a[np.isfinite(a)]
 return {'n':int(len(a)),'min':float(a.min()),'median':float(np.median(a)),'p95':float(np.percentile(a,95)),'max':float(a.max())} if len(a) else {'n':0}
def csv_write(name,rows):
 if not rows:return
 keys=list(dict.fromkeys(k for row in rows for k in row))
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def rotation_gap(q0,q1):
 return np.degrees((Rotation.from_quat(q1)*Rotation.from_quat(q0).inv()).magnitude())
def pose6_gap(v0,v1):
 return float(np.linalg.norm(v1[:3]-v0[:3])*1000),float(np.degrees((Rotation.from_rotvec(v1[3:])*Rotation.from_rotvec(v0[3:]).inv()).magnitude()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read_arrays(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}

def main():
 OUT.mkdir(parents=True,exist_ok=True);kine=TianjiKinematics()
 source_rows=[]
 for run in ['replay','closed']:
  provenance=json.loads((DATA/f'provenance/{run}_source_provenance.json').read_text())
  for name,item in provenance['files'].items():
   rel=item['path'].split('/diffusion_policy/',1)[-1]
   # Paths have a project directory named diffusion_policy and may have another package segment.
   tail=item['path'].split('/home/yuchen/project/diffusion_policy/',1)[-1]
   file=SRC/tail
   source_rows.append({'run':run,'module':name,'source_file':str(file),'present':file.is_file(),'sha256':sha(file) if file.is_file() else None,'expected_sha256':item['sha256'],'matches':file.is_file() and sha(file)==item['sha256']})
 # The FK implementation is the server copy and its runtime support has no network transport.
 server_driver=Path('/home/jiyuchen/project/WYS/diffusion_policy/third_party/bimanual_teleop/devices/tianji/driver.py')
 assert sha(server_driver)==json.loads((DATA/'provenance/replay_source_provenance.json').read_text())['files']['driver']['sha256']
 decision_rows=[];camera_rows=[];layer_rows=[];init_rows=[];receipt_rows=[];results={};datasets={}
 for run in ['replay','closed']:
  path=DATA/f'motion/{run}/trial_0001';d=read_arrays(path/'trace_decisions.npz');f=read_arrays(path/'trace_feedback.npz');c=read_arrays(path/'trace_commands.npz');h=read_arrays(path/'trace_hands.npz');meta=json.loads((path/'trace_meta.json').read_text());trial=json.loads((path/'trial.json').read_text());events=[json.loads(s) for s in (path/'events.jsonl').read_text().splitlines()]
  ft=f['received_ns'];fq=f['q'];positions=np.empty((len(ft),2,3));quats=np.empty((len(ft),2,4));ct_positions=np.empty_like(positions)
  for side,name in enumerate(SIDES):
   for i,q in enumerate(fq[:,side]):
    pose=kine.fk(name,tuple(q));positions[i,side]=pose.position_m;quats[i,side]=pose.orientation_xyzw
    ct_positions[i,side]=kine.fk(name,tuple(f['controller_target'][i,side])).position_m
  def actual_at(t,side):
   if t<ft[0] or t>ft[-1]:return None
   q=tuple(np.interp(t,ft,fq[:,side,j]) for j in range(7));p=kine.fk(SIDES[side],q);return np.array(p.position_m),np.array(p.orientation_xyzw),q
  recorded=[x for x in events if x['event']=='recorded_window'];schedule=[x for x in events if x['event']=='schedule'];pause=[x for x in events if x['event']=='pause'];active_first=min(x['times_ns'][0] for x in schedule);active_end=max(x['monotonic_ns'] for x in pause)
  for index in range(len(d['present'])):
   dm=meta['decisions'][index];anchor=int(d['anchor_ns'][index]);started=int(d['started_ns'][index]);ready=int(d['inputs_ready_ns'][index]);returned=int(d['returned_ns'][index]);real_prefix='real_' if run=='replay' else '';live=np.asarray(d[real_prefix+'robot_eef_pose'][index,-1]);alignment=dm['real_alignment'] if run=='replay' else dm['alignment'];capture_upper=int(recorded[index]['monotonic_ns']) if run=='replay' else int(d['observed_ns'][index]);queries=np.asarray(alignment['query_ns'],dtype=np.int64)
   all_camera_stamps=np.asarray([alignment['camera_ns'][cam] for cam in CAMS]);three_camera_spans=np.ptp(all_camera_stamps,axis=0)/1e6;state_bracket_gaps=np.diff(np.asarray(list(alignment['state_brackets_ns'].values())),axis=-1).ravel()/1e6
   for cam in CAMS:
    stamps=np.asarray(alignment['camera_ns'][cam],dtype=np.int64);pixels=d[real_prefix+cam][index]
    camera_rows.append({'run':run,'decision':index,'camera':cam,'query_first_ns':int(queries[0]),'query_last_ns':int(queries[-1]),'frame_first_ns':int(stamps[0]),'frame_last_ns':int(stamps[-1]),'duplicate_timestamp':bool(stamps[0]==stamps[-1]),'duplicate_pixels':bool(np.array_equal(pixels[0],pixels[-1])),'history_frame_span_ms':float((stamps[-1]-stamps[0])/1e6),'query_skew_first_ms':float((stamps[0]-queries[0])/1e6),'query_skew_last_ms':float((stamps[-1]-queries[-1])/1e6),'max_absolute_query_skew_ms':float(abs(stamps-queries).max()/1e6),'three_camera_span_first_ms':float(three_camera_spans[0]),'three_camera_span_last_ms':float(three_camera_spans[-1]),'state_interpolation_largest_bracket_ms':float(state_bracket_gaps.max()),'frame_age_at_capture_upperbound_ms':float((capture_upper-stamps[-1])/1e6),'capture_upperbound_kind':'post_store_event' if run=='replay' else 'get_obs_return','frame_age_at_inference_started_ms':float((started-stamps[-1])/1e6),'frame_age_at_inference_return_ms':float((returned-stamps[-1])/1e6),'live_capture_after_inference_started':bool(stamps[-1]>started),'live_capture_after_inference_returned':bool(stamps[-1]>returned)})
   for side,name in enumerate(SIDES):
    a=actual_at(anchor,side);pose_input=live[side*6:side*6+6];input_pos_err=np.linalg.norm(a[0]-pose_input[:3])*1000;input_rot_err=rotation_gap(Rotation.from_rotvec(pose_input[3:]).as_quat(),a[1])
    for label,t0 in [('anchor_to_return',anchor),('started_to_return',started),('inputs_ready_to_return',ready)]:
     start_pose=actual_at(t0,side);end_pose=actual_at(returned,side);valid=t0<=returned and start_pose is not None and end_pose is not None;sample=(ft>=t0)&(ft<=returned);row={'run':run,'decision':index,'side':name,'interval':label,'start_ns':t0,'end_ns':returned,'duration_ms':(returned-t0)/1e6,'time_order_valid':bool(valid),'cache_before_formal_trial':bool(returned<int(trial['started_monotonic_ns'])),'feedback_samples':int(sample.sum()),'input_vs_actual_at_live_anchor_mm':float(input_pos_err),'input_vs_actual_at_live_anchor_deg':float(input_rot_err)}
     if valid:
      pp=np.vstack([start_pose[0],positions[sample,side],end_pose[0]]);qq=np.vstack([start_pose[1],quats[sample,side],end_pose[1]]);delta=(end_pose[0]-start_pose[0])*1000
      row.update({'delta_x_mm':float(delta[0]),'delta_y_mm':float(delta[1]),'delta_z_mm':float(delta[2]),'endpoint_translation_mm':float(np.linalg.norm(delta)),'maximum_translation_from_start_mm':float(np.max(np.linalg.norm(pp-start_pose[0],axis=1))*1000),'translation_path_length_mm':float(np.linalg.norm(np.diff(pp,axis=0),axis=1).sum()*1000),'endpoint_rotation_deg':float(rotation_gap(start_pose[1],end_pose[1])),'maximum_rotation_from_start_deg':float(np.max(rotation_gap(start_pose[1],qq))),'rotation_path_length_deg':float(rotation_gap(qq[:-1],qq[1:]).sum())})
      hm=(h['feedback_side']==side)&h['feedback_present'];ht=h['feedback_received_ns'][hm];hq=h['feedback_q'][hm];ha=np.array([np.interp(t0,ht,hq[:,j]) for j in range(20)]);hb=np.array([np.interp(returned,ht,hq[:,j]) for j in range(20)]);hand_delta=np.degrees(hb-ha);hand_window=(ht>=t0)&(ht<=returned);row['hand_endpoint_max_joint_deg']=float(abs(hand_delta).max());row['hand_maximum_joint_excursion_deg']=float(np.max(abs(np.vstack([ha,hq[hand_window],hb])-ha))*180/np.pi)
     decision_rows.append(row)
  schedule_map={int(s['generation']):(s, int(s.get('prediction_id',-1)) if run=='replay' else index) for index,s in enumerate(schedule)}
  full=c['accepted']&c['q_cmd_present'].all(axis=1)&c['requested_present'].all(axis=1)&c['command_fk_present'].all(axis=1)
  for row_index in np.flatnonzero(full):
   for side,name in enumerate(SIDES):
    stamp=int(c['receipt_ns'][row_index]);a=actual_at(stamp,side);req=c['requested_xyz'][row_index,side];applied=c['command_fk_xyz'][row_index,side];reqq=c['requested_quat'][row_index,side];cmdq=c['command_fk_quat'][row_index,side]
    row={'run':run,'row':int(row_index),'command_id':str(c['command_id'][row_index]),'side':name,'prediction_id':int(c['prediction_id'][row_index]),'step_id':int(c['step_id'][row_index]),'step_present':bool(c['step_present'][row_index]),'receipt_ns':stamp,'feedback_snapshot_ns':int(c['feedback_received_ns'][row_index]),'feedback_snapshot_age_at_receipt_ms':float((stamp-c['feedback_received_ns'][row_index])/1e6),'request_to_command_fk_mm':float(np.linalg.norm(req-applied)*1000),'request_to_command_fk_deg':float(rotation_gap(reqq,cmdq)),'request_to_actual_mm':float(np.linalg.norm(req-a[0])*1000),'request_to_actual_deg':float(rotation_gap(reqq,a[1])),'command_fk_to_actual_mm':float(np.linalg.norm(applied-a[0])*1000),'command_fk_to_actual_deg':float(rotation_gap(cmdq,a[1])),'limited':bool(c['limited'][row_index,side]),'progress':float(c['progress'][row_index,side]),'sdk_accepted':bool(c['sdk_accepted'][row_index]),'accepted':bool(c['accepted'][row_index])}
    pair=schedule_map.get(int(c['chunk_id'][row_index]));mapped=-1;phase='unmapped'
    if pair is not None:
     sch,mapped=pair;clock=int(c['started_ns'][row_index]);phase='pre_schedule_hold' if clock<int(sch['times_ns'][0]) else ('policy_step' if clock<int(sch['times_ns'][-1])+round(1e9/30) else 'between_block_hold')
     if run=='replay' and mapped<0:phase='calibration_only_approach/'+phase
    row.update(phase=phase,mapped_prediction_index=int(mapped),within_saved_observation=bool(0<=mapped<len(d['present'])));layer_rows.append(row)
  statuses=meta['status'];status_times=[x['observed_monotonic_ns'] for x in statuses if x.get('observed_monotonic_ns') is not None];status_last=max(status_times);qdelta=f['controller_target']-fq;active=(ft>=active_first)&(ft<=active_end)
  command_categories={'complete_accepted_arm':int(full.sum()),'sdk_receipt_only_without_joint_payload':int((~c['q_cmd_present'].any(axis=1)&c['sdk_accepted']).sum()),'other_incomplete_command_rows':int((~full&c['q_cmd_present'].any(axis=1)).sum())}
  for cat,count in command_categories.items():receipt_rows.append({'run':run,'category':cat,'count':count,'device_filter_recoverable':cat=='complete_accepted_arm','qualification':'device_id was not saved in the legacy trace; missing payload is not rejection'})
  rr={'trace_valid':bool(meta['valid']),'invalid_reason':meta['invalid_reason'],'dropped':meta['dropped'],'decision_count':int(d['present'].sum()),'event_prediction_count':sum(x['event']=='prediction' for x in events),'formal_motion_first_ns':active_first,'formal_motion_end_ns':active_end,'status_coverage_first_ns':min(status_times),'status_coverage_last_ns':status_last,'status_ends_before_formal_motion_s':float((active_first-status_last)/1e9),'formal_motion_status_events_preserved':sum(active_first<=t<=active_end for t in status_times),'status_kind_counts':{kind:sum(e['kind']==kind for e in statuses) for kind in {x['kind'] for x in statuses}},'command_categories':command_categories,'hand_commands_count':len(h['accepted']),'hand_commands_accepted':int(h['accepted'].sum()),'feedback_timestamp_gap_ms':stat(np.diff(ft)/1e6),'formal_feedback_timestamp_gap_ms':stat(np.diff(ft[active])/1e6),'controller_reported_target_minus_actual_joint_rad':stat(abs(qdelta)),'controller_reported_target_exact_equal_fraction':float(np.mean(qdelta==0)),'controller_reported_target_fk_minus_actual_mm':stat(np.linalg.norm(ct_positions[active]-positions[active],axis=2)*1000),'controller_reported_target_not_delivery_ack':True,'outcome':trial['outcome'],'reason':trial.get('reason')}
  for side,name in enumerate(SIDES):
   selected=[x for x in layer_rows if x['run']==run and x['side']==name];rr[name+'_command_layers']={metric:stat([x[metric] for x in selected]) for metric in ['request_to_command_fk_mm','request_to_command_fk_deg','request_to_actual_mm','request_to_actual_deg','command_fk_to_actual_mm','command_fk_to_actual_deg']}
  initrows={}
  for label,stamp in [('trial_begin',int(trial['started_monotonic_ns'])),('first_live_observation',int(d['anchor_ns'][0]))]:
   for side,name in enumerate(SIDES):
    a=actual_at(stamp,side);ref=np.asarray(d['robot_eef_pose'][0,-1,side*6:side*6+6]) if run=='replay' else np.asarray(datasets['replay']['demo_initial'][side*6:side*6+6]);x=a[0]*1000;q=a[1];row={'run':run,'stage':label,'side':name,'stamp_ns':stamp,'actual_x_mm':float(x[0]),'actual_y_mm':float(x[1]),'actual_z_mm':float(x[2]),'actual_rotvec_x_rad':float(Rotation.from_quat(q).as_rotvec()[0]),'actual_rotvec_y_rad':float(Rotation.from_quat(q).as_rotvec()[1]),'actual_rotvec_z_rad':float(Rotation.from_quat(q).as_rotvec()[2]),'reference_position_gap_mm':float(np.linalg.norm(a[0]-ref[:3])*1000),'reference_rotation_gap_deg':float(rotation_gap(Rotation.from_rotvec(ref[3:]).as_quat(),q))};init_rows.append(row)
  rr['source_counter_sampling_gaps']={name:{'sampled_intervals_with_gap':int(np.sum(np.diff(f['source_sequence'][active,side])>1)),'unobserved_source_counter_steps':int(np.maximum(np.diff(f['source_sequence'][active,side])-1,0).sum()),'interpretation':'SDK snapshot sampling can skip source counters; this is not a UDP loss estimate.'} for side,name in enumerate(SIDES)}
  results[run]=rr;datasets[run]={'demo_initial':d['robot_eef_pose'][0,-1].copy(),'live_initial':d[('real_' if run=='replay' else '')+'robot_eef_pose'][0,-1].copy(),'hand_initial':d[('real_' if run=='replay' else '')+'hand_joint'][0,-1].copy(),'decisions':d,'positions':positions,'quats':quats,'feedback_ns':ft}
  np.savez_compressed(OUT/f'{run}_fk_cache.npz',received_ns=ft,actual_xyz=positions,actual_quat=quats,reported_controller_target_xyz=ct_positions)
 results['initial_cross_run']={}
 for side,name in enumerate(SIDES):
  sl=slice(side*6,side*6+6);p,r=pose6_gap(datasets['replay']['live_initial'][sl],datasets['closed']['live_initial'][sl]);delta=np.degrees(datasets['closed']['hand_initial'][side*20:side*20+20]-datasets['replay']['hand_initial'][side*20:side*20+20]);results['initial_cross_run'][name]={'live_observation_position_mm':p,'live_observation_rotation_deg':r,'hand_joint_mean_abs_delta_deg':float(abs(delta).mean()),'hand_joint_max_abs_delta_deg':float(abs(delta).max())}
 results['inference_motion_summaries']={}
 for run in ['replay','closed']:
  for side in SIDES:
   for interval in ['anchor_to_return','started_to_return','inputs_ready_to_return']:
    rows=[x for x in decision_rows if x['run']==run and x['side']==side and x['interval']==interval and x['time_order_valid']]
    results['inference_motion_summaries'][f'{run}/{side}/{interval}']={metric:stat([x[metric] for x in rows]) for metric in ['endpoint_translation_mm','maximum_translation_from_start_mm','endpoint_rotation_deg','maximum_rotation_from_start_deg','hand_maximum_joint_excursion_deg']}
 results['camera_summaries']={}
 for run in ['replay','closed']:
  for cam in CAMS:
   rows=[x for x in camera_rows if x['run']==run and x['camera']==cam]
   results['camera_summaries'][f'{run}/{cam}']={'count':len(rows),'duplicate_timestamp_windows':sum(x['duplicate_timestamp'] for x in rows),'duplicate_pixel_windows':sum(x['duplicate_pixels'] for x in rows),'skew_ms':stat([x['max_absolute_query_skew_ms'] for x in rows]),'frame_age_at_capture_upperbound_ms':stat([x['frame_age_at_capture_upperbound_ms'] for x in rows]),'replay_real_capture_not_actual_model_input':run=='replay'}
 results['formal_model_interval_summaries']={}
 for run in ['replay','closed']:
  for side in SIDES:
   rows=[x for x in decision_rows if x['run']==run and x['side']==side and x['interval']=='started_to_return' and x['time_order_valid'] and not x['cache_before_formal_trial']]
   results['formal_model_interval_summaries'][f'{run}/{side}']={metric:stat([x[metric] for x in rows]) for metric in ['endpoint_translation_mm','maximum_translation_from_start_mm','endpoint_rotation_deg','maximum_rotation_from_start_deg','hand_maximum_joint_excursion_deg']}
 results['command_layers_by_phase']={}
 for run in ['replay','closed']:
  for side in SIDES:
   for phase in sorted({x['phase'] for x in layer_rows if x['run']==run}):
    rows=[x for x in layer_rows if x['run']==run and x['side']==side and x['phase']==phase]
    results['command_layers_by_phase'][f'{run}/{side}/{phase}']={metric:stat([x[metric] for x in rows]) for metric in ['request_to_command_fk_mm','request_to_command_fk_deg','request_to_actual_mm','request_to_actual_deg','command_fk_to_actual_mm','command_fk_to_actual_deg']}
 results['source_verification']=source_rows
 results['nonrecoverable_limits']=['All formal-motion driver status events are outside the preserved status window. Terminal runtime events are separate and preserved.','Closed observations/RNG for predictions 48..63 were dropped. Their actions exist in events but inputs cannot be reconstructed.','Legacy command receipts lack device_id and accepted_present. Payload-valid arm rows can be selected, but orphan event devices cannot be reconstructed.','Replay first action was computed before its unique approach segment; replay real images were acquired after demonstration inference. This is not the same online decision protocol as closed.','No external physical camera calibration or manufacturer-level meaning of m_FB_Joint_Cmd is proven by these arrays.','All present observations and all requested/applied/feedback/hand numerical streams are audited; passing this audit does not turn legacy trace_valid=false into a valid complete experiment.']
 (OUT/'existing_motion_audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 csv_write('decision_motion.csv',decision_rows);csv_write('camera_alignment.csv',camera_rows);csv_write('command_layers.csv',layer_rows);csv_write('initialization.csv',init_rows);csv_write('receipt_audit.csv',receipt_rows);csv_write('source_verification.csv',source_rows)
 print(json.dumps({'outputs':str(OUT),'decision_interval_rows':len(decision_rows),'camera_rows':len(camera_rows),'command_layer_rows':len(layer_rows),'all_provided_sources_match':all(x['matches'] for x in source_rows)},ensure_ascii=False))

if __name__=='__main__':main()
