import importlib.util,json,tempfile,unittest
from pathlib import Path
import numpy as np
SPEC=importlib.util.spec_from_file_location('motion_qc',Path(__file__).with_name('qc_motion_trial.py'));MODULE=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(MODULE)

class MotionQCTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.p=Path(self.temp.name)
  alignment={'query_ns':[10,11],'camera_ns':{c:[10,11] for c in ['camera_0','camera_1','camera_2']}}
  self.meta={'valid':True,'dropped':{'decisions':0,'feedback':0,'commands':0,'hands':0,'status':0},'recording_start_ns':9,'recording_end_ns':20,'critical_status_dropped':0,'status_summary':{},'decisions':[{'control_input':'real','alignment':alignment,'live_capture_started_ns':11,'live_capture_returned_ns':12}]}
  (self.p/'trace_meta.json').write_text(json.dumps(self.meta));(self.p/'trial.json').write_text(json.dumps({'outcome':'timeout','reason':'fixed bound','dropped_events':0}));(self.p/'events.jsonl').write_text(json.dumps({'event':'schedule','times_ns':[15]})+'\n'+json.dumps({'event':'pause','monotonic_ns':19})+'\n')
  d={'present':np.array([True]),'action_rows':np.array([8]),'actions':np.zeros((1,8,52)),'robot_eef_pose':np.zeros((1,2,12)),'hand_joint':np.zeros((1,2,40)),'started_ns':np.array([11]),'returned_ns':np.array([14])}
  d.update({c:np.zeros((1,2,2,2,3),dtype=np.uint8) for c in ['camera_0','camera_1','camera_2']});np.savez(self.p/'trace_decisions.npz',**d)
  np.savez(self.p/'trace_feedback.npz',received_ns=np.array([10,13,18]),q_present=np.ones((3,2),bool),q=np.zeros((3,2,7)),controller_present=np.ones((3,2),bool),controller_target=np.zeros((3,2,7)))
  self.commands={'device_id':np.array(['tianji','wuji_left_hand']),'accepted_present':np.array([True,False]),'accepted':np.array([True,False]),'q_cmd_present':np.ones((2,2),bool),'command_fk_present':np.ones((2,2),bool),'requested_present':np.ones((2,2),bool),'q_cmd':np.zeros((2,2,7))};np.savez(self.p/'trace_commands.npz',**self.commands)
  np.savez(self.p/'trace_hands.npz',feedback_present=np.ones(2,bool),feedback_q=np.zeros((2,20)))
 def write_meta(self): (self.p/'trace_meta.json').write_text(json.dumps(self.meta))
 def test_complete_trace_passes_and_foreign_receipt_not_arm_rejection(self):
  r=MODULE.inspect_trial(self.p);self.assertTrue(r['valid_for_numeric_comparison'],r);self.assertEqual(r['measurements']['explicit_rejected_arm_commands'],0);self.assertEqual(r['measurements']['foreign_device_receipt_rows'],1)
 def test_status_loss_invalidates_recording(self):
  self.meta['dropped']['status']=1;self.write_meta();self.assertFalse(MODULE.inspect_trial(self.p)['valid_for_numeric_comparison'])
 def test_post_inference_live_calibration_capture_rejected(self):
  self.meta['decisions'][0]['control_input']='demonstration';self.meta['decisions'][0]['real_alignment']=self.meta['decisions'][0]['alignment'];self.meta['decisions'][0]['live_capture_returned_ns']=16;self.write_meta();r=MODULE.inspect_trial(self.p);self.assertTrue(any('after demonstration inference' in e for e in r['failures']))
 def test_missing_device_acceptance_semantics_rejected(self):
  self.commands.pop('accepted_present');np.savez(self.p/'trace_commands.npz',**self.commands);self.assertFalse(MODULE.inspect_trial(self.p)['valid_for_numeric_comparison'])
 def test_stable_condition_requires_recorded_gate(self):
  self.assertFalse(MODULE.inspect_trial(self.p,stable_condition=True)['valid_for_numeric_comparison']);self.meta['decisions'][0]['stability']={'enabled':True};self.write_meta();self.assertTrue(MODULE.inspect_trial(self.p,stable_condition=True)['valid_for_numeric_comparison'])

if __name__=='__main__':unittest.main()
