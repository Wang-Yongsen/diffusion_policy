"""Offline trace QC only. Imports no robot runtime, SDK, networking, or supplied scripts."""
import argparse,json
from pathlib import Path
import numpy as np

REQUIRED=('trace_meta.json','trace_decisions.npz','trace_feedback.npz','trace_commands.npz','trace_hands.npz','events.jsonl','trial.json')
def arrays(path):
 with np.load(path,allow_pickle=False) as f:return {key:f[key] for key in f.files}
def inspect_trial(directory, *, max_decisions=24, max_active_s=10.0, stable_condition=False):
 p=Path(directory);failures=[];warnings=[];measurements={}
 def require(ok,reason):
  if not ok:failures.append(reason)
 missing=[name for name in REQUIRED if not (p/name).is_file()]
 if missing:return {'valid_for_numeric_comparison':False,'failures':['missing required files: '+', '.join(missing)],'warnings':[],'measurements':{}}
 try:
  m=json.loads((p/'trace_meta.json').read_text());t=json.loads((p/'trial.json').read_text());d=arrays(p/'trace_decisions.npz');f=arrays(p/'trace_feedback.npz');c=arrays(p/'trace_commands.npz');h=arrays(p/'trace_hands.npz');events=[json.loads(line) for line in (p/'events.jsonl').read_text().splitlines() if line.strip()]
  require(m.get('valid') is True,'trace_valid is not true');require(all(int(n)==0 for n in m.get('dropped',{}).values()),'one or more trace streams dropped records');require(m.get('critical_status_dropped')==0,'critical_status_dropped is absent or nonzero');require(isinstance(m.get('status_summary'),dict),'status_summary is absent')
  start=m.get('recording_start_ns');end=m.get('recording_end_ns');require(isinstance(start,int) and isinstance(end,int) and end>=start,'recording coverage start/end are missing or invalid')
  n=len(d['present']);measurements['decisions_saved']=n;require(0<n<=max_decisions,'decision count outside fixed-batch bounds');require(bool(np.all(d['present'])),'one or more decision slots are absent');require(bool(np.all(d['action_rows']>0)),'empty decision action chunk');require(bool(np.all(np.isfinite(d['actions']))),'nonfinite decision actions');require(bool(np.all(d['returned_ns']>=d['started_ns'])),'decision inference returned before it started')
  for key in ('robot_eef_pose','hand_joint'):
   require(bool(np.all(np.isfinite(d[key]))),key+' contains nonfinite values')
  for cam in ('camera_0','camera_1','camera_2'):
   require(cam in d and d[cam].ndim==5 and d[cam].shape[:2]==(n,2) and d[cam].shape[-1]==3 and d[cam].dtype==np.uint8,cam+' image windows are missing or malformed')
  require(len(m.get('decisions',[]))==n,'decision metadata count mismatch')
  duplicate={cam:0 for cam in ('camera_0','camera_1','camera_2')};max_skew=0.;max_capture_age=0.;max_span=0.
  for i,dm in enumerate(m.get('decisions',[])):
   if i>=n:break
   capture_start=dm.get('live_capture_started_ns');capture_end=dm.get('live_capture_returned_ns');require(isinstance(capture_start,int) and isinstance(capture_end,int) and capture_start<=capture_end,f'decision {i}: missing/reversed live capture interval')
   alignment=dm.get('real_alignment') if dm.get('control_input')=='demonstration' else dm.get('alignment');require(isinstance(alignment,dict),f'decision {i}: missing live alignment')
   if not isinstance(alignment,dict):continue
   query=np.asarray(alignment.get('query_ns',[]),dtype=np.int64);require(len(query)==2,f'decision {i}: wrong observation history length')
   stamps=[]
   for cam in duplicate:
    cs=np.asarray(alignment.get('camera_ns',{}).get(cam,[]),dtype=np.int64);require(len(cs)==2,f'decision {i}: missing {cam} stamps')
    if len(cs)!=2 or len(query)!=2:continue
    stamps.append(cs);duplicate[cam]+=int(cs[0]==cs[1]);max_skew=max(max_skew,float(abs(cs-query).max()/1e6))
    if isinstance(capture_end,int):max_capture_age=max(max_capture_age,float((capture_end-cs[-1])/1e6))
   if len(stamps)==3:max_span=max(max_span,float(np.ptp(np.asarray(stamps),axis=0).max()/1e6))
   if dm.get('control_input')=='demonstration':
    require(bool(d.get('real_present',np.zeros(n,bool))[i]),f'decision {i}: calibration missing paired real window')
    for cam in duplicate:require('real_'+cam in d and d['real_'+cam].shape==d[cam].shape and d['real_'+cam].dtype==np.uint8,f'decision {i}: missing/malformed real {cam} window')
    if isinstance(capture_end,int):require(capture_end<=int(d['started_ns'][i]),f'decision {i}: paired real capture occurred after demonstration inference started')
   if isinstance(start,int) and isinstance(end,int):require(start<=int(d['started_ns'][i])<=int(d['returned_ns'][i])<=end,f'decision {i}: inference outside recording coverage')
   if stable_condition:require(isinstance(dm.get('stability'),dict),f'decision {i}: S condition has no stability diagnostic')
  measurements.update(duplicate_camera_history_windows=duplicate,max_camera_query_skew_ms=max_skew,max_camera_span_ms=max_span,max_frame_age_at_capture_ms=max_capture_age)
  # These are the existing deployment budgets, not newly relaxed limits.
  require(max_skew<=40.001,'camera query skew exceeds 40ms');require(max_span<=50.001,'three-camera span exceeds 50ms');require(max_capture_age<=150.001,'frame is older than 150ms at capture')
  require(bool(np.all(np.diff(f['received_ns'])>0)),'feedback timestamps not strictly increasing');require(bool(np.all(f['q_present'])),'actual arm joints missing');require(bool(np.all(np.isfinite(f['q']))),'nonfinite actual arm joints');require(bool(np.all(f['controller_present'])),'controller-reported target missing');require(bool(np.all(np.isfinite(f['controller_target']))),'nonfinite controller-reported target')
  require('device_id' in c,'command receipt device_id not preserved');require('accepted_present' in c,'command accepted_present not preserved')
  if 'device_id' in c and 'accepted_present' in c:
   arm=c['device_id'].astype(str)=='tianji';known=arm&c['accepted_present'];payload=arm&c['q_cmd_present'].all(axis=1);accepted=known&c['accepted'];rejected=known&~c['accepted'];require(bool(np.all(c['accepted_present'][payload])),'complete arm command has unknown executor acceptance');require(bool(np.all(c['command_fk_present'][accepted])),'accepted arm command missing constrained FK');require(bool(np.all(c['requested_present'][accepted])),'accepted arm command missing request');require(bool(np.all(np.isfinite(c['q_cmd'][accepted]))),'nonfinite accepted arm command')
   measurements.update(accepted_arm_commands=int(accepted.sum()),explicit_rejected_arm_commands=int(rejected.sum()),foreign_device_receipt_rows=int((~arm).sum()),arm_receipt_only_rows=int((arm&~c['accepted_present']).sum()))
   if np.any(~arm):warnings.append('foreign receipts ignored by exact device_id, never interpreted as arm rejection')
   if np.any(rejected):warnings.append('explicit arm rejection is a possible valid trial outcome; preserve its cause in events/status')
  require(bool(np.all(h['feedback_present'])),'hand feedback joints missing');require(bool(np.all(np.isfinite(h['feedback_q']))),'nonfinite actual hand joints')
  schedules=[event for event in events if event.get('event')=='schedule'];pauses=[event for event in events if event.get('event')=='pause']
  if schedules and pauses:
   active_start=min(int(e['times_ns'][0]) for e in schedules);active_end=min(int(e['monotonic_ns']) for e in pauses if int(e['monotonic_ns'])>=active_start);elapsed=(active_end-active_start)/1e9;measurements['active_wall_s']=elapsed;require(elapsed<=max_active_s+.2,'active period exceeds fixed wall limit plus 200ms stopping allowance')
   if isinstance(start,int) and isinstance(end,int):require(start<=active_start<=active_end<=end,'recording does not cover formal active period')
  else:require(False,'schedule/pause boundaries are missing')
  if t.get('record_error'):require(False,'TrialRecorder writer failed')
  require(int(t.get('dropped_events',0))==0,'TrialRecorder event drops');measurements['outcome']=t.get('outcome');measurements['reason']=t.get('reason')
 except (KeyError,ValueError,TypeError,OSError,IndexError) as error:failures.append('trace schema/read error: '+str(error))
 return {'valid_for_numeric_comparison':not failures,'failures':failures,'warnings':warnings,'measurements':measurements,'scope':'Offline motion trace structure only. Batch QC must separately verify identical initialization, fixed V/S conditions, no human intervention, condition repetitions, and task/phase outcome. Rejection or bounded timeout is an outcome, not automatically invalid recording.'}

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--trial',required=True,type=Path);parser.add_argument('--output',type=Path);parser.add_argument('--stable-condition',action='store_true');parser.add_argument('--max-decisions',type=int,default=24);parser.add_argument('--max-active-s',type=float,default=10.)
 args=parser.parse_args();result=inspect_trial(args.trial,max_decisions=args.max_decisions,max_active_s=args.max_active_s,stable_condition=args.stable_condition);text=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
 if args.output:args.output.write_text(text)
 else:print(text,end='')
 return 0 if result['valid_for_numeric_comparison'] else 2

if __name__=='__main__':raise SystemExit(main())
