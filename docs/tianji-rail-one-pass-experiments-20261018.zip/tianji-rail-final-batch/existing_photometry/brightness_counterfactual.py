"""Independent saved-input brightness intervention; no device construction or calls."""
from pathlib import Path
import json
import sys
import numpy as np
import torch
from PIL import Image, ImageDraw

PROJECT=Path('/home/jiyuchen/project/WYS/diffusion_policy')
ROOT=Path('/home/jiyuchen/.codex/visualizations/2026/10/17/01a14907-347a-7411-9c80-9b9dec2b6da1/received_decision_trace_20261018')
SOURCE=ROOT/'tianji-rail-decision-trace-20261018/motion/replay/trial_0001/trace_decisions.npz'
OUT=Path(__file__).parent
KEYS=('camera_0','camera_1','camera_2','robot_eef_pose','hand_joint')
sys.path.insert(0,str(PROJECT))
from eval_tianji_rail import load_policy
from diffusion_policy.real_world.tianji_rail_env import preprocess_observation

def match_mean(image,target_mean,mode):
    x=image.astype(np.float64)
    low,high=(-255.,255.) if mode=='offset' else (0.,16.)
    for _ in range(45):
        mid=(low+high)/2
        y=np.clip(x+mid if mode=='offset' else x*mid,0,255)
        if y.mean()<target_mean:low=mid
        else:high=mid
    y=np.rint(np.clip(x+(low+high)/2 if mode=='offset' else x*((low+high)/2),0,255)).astype(np.uint8)
    return y,float((low+high)/2)

torch.set_num_threads(2)
policy,cfg,key=load_policy(PROJECT/'data/outputs/2026.10.16/23.09.56_tianji_rail/checkpoints/epoch=0050.ckpt','cpu')
policy.eval()
def predict(obs,seed):
    torch.manual_seed(seed);np.random.seed(seed);policy.reset()
    x=preprocess_observation(obs,cfg.task.shape_meta,cfg.task.dataset)
    with torch.inference_mode():
        return policy.predict_action({k:torch.from_numpy(v).unsqueeze(0) for k,v in x.items()})['action'][0].numpy()

report={'device':'cpu','threads':2,'model_key':key,'seeds':[42,43,44],
        'normalization':'Mean RGB pixel intensity matched separately for each of two frames, with clipping and final uint8 rounding.',
        'interpretation':'These are offline input sensitivity tests against the same-seed demo prediction. They do not establish the correct action for a changed scene, prove a hardware exposure defect, or show physical closed-loop success.',
        'decisions':{}}
predictions={}
with np.load(SOURCE,allow_pickle=False) as trace:
    for index in (0,1):
        demo={k:np.array(trace[k][index],copy=True) for k in KEYS}
        realcam=np.array(trace['real_camera_1'][index],copy=True)
        variants={'EE':demo['camera_1'],'real_camera1':realcam}
        transform={}
        for name,original,target,mode in (
            ('real_camera1_offset',realcam,demo['camera_1'],'offset'),
            ('real_camera1_gain',realcam,demo['camera_1'],'gain'),
            ('demo_camera1_dark_offset',demo['camera_1'],realcam,'offset')):
            adjusted=[];params=[]
            for frame,target_frame in zip(original,target):
                y,v=match_mean(frame,float(target_frame.mean()),mode);adjusted.append(y);params.append(v)
            variants[name]=np.stack(adjusted);transform[name]=params
        row={'source_demo_mean':[float(x.mean()) for x in demo['camera_1']],
             'source_real_mean':[float(x.mean()) for x in realcam], 'transform_parameters':transform,'conditions':{}}
        base={}
        for condition,images in variants.items():
            obs={k:np.array(v,copy=True) for k,v in demo.items()};obs['camera_1']=images
            summaries=[]
            for seed in (42,43,44):
                action=predict(obs,seed);predictions[f'd{index}_{condition}_s{seed}']=action
                if condition=='EE':base[seed]=action
                diff=(action[:,:3]-base[seed][:,:3])*1000
                s={'seed':seed,'mean_delta_xyz_mm':diff.mean(0).tolist(),
                   'mean_target_distance_to_EE_mm':float(np.linalg.norm(diff,axis=1).mean()),
                   'last_delta_xyz_mm':diff[-1].tolist(),
                   'last_absolute_xyz_mm':(action[-1,:3]*1000).tolist()}
                summaries.append(s)
                print(index,condition,seed,s['mean_target_distance_to_EE_mm'],s['mean_delta_xyz_mm'],flush=True)
            row['conditions'][condition]={'summaries':summaries,
               'mean_RGB':[float(x.mean()) for x in images],
               'pixel_MAE_to_demo':float(np.abs(images.astype(float)-demo['camera_1'].astype(float)).mean()),
               'target_distance_mm_mean_over_seeds':float(np.mean([x['mean_target_distance_to_EE_mm'] for x in summaries])),
               'delta_xyz_mm_mean_over_seeds':np.mean([x['mean_delta_xyz_mm'] for x in summaries],axis=0).tolist()}
        report['decisions'][str(index)]=row
        sheet=Image.new('RGB',(320*len(variants),270),'white');draw=ImageDraw.Draw(sheet)
        for c,(name,images) in enumerate(variants.items()):
            sheet.paste(Image.fromarray(images[-1]).resize((320,240)),(c*320,30));draw.text((c*320+5,8),name,fill='black')
        sheet.save(OUT/f'brightness_variants_dec{index}.png')
np.savez_compressed(OUT/'brightness_predictions.npz',**predictions)
(OUT/'brightness_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Saved',OUT/'brightness_results.json',flush=True)
